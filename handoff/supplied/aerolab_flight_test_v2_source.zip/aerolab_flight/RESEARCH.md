# GitHub 对照与具体落地 — AEROLAB 02

查阅日期：2026-10-11。通过 GitHub 连接读取作者仓库源码、诊断记录与物理说明；使用固定提交编号记录本次参考范围，完整字段见 `source_references.json`。

不是下载几个仓库后直接宣称移植；本次新写的是适配 NF-01 自有动力学的 C/WASM 教官和浏览器输入、相机、诊断工具。**没有集成 Unity、BepInEx、Harmony、Nuclear Option 游戏文件、Three.js 或外部 Rust crate。**

## MouseFlight：世界准星、自由观察与相机

源码： https://github.com/brihernandez/MouseFlight/blob/2172d104ab7ef91beef1fbfd42f2a15c9a99f359/Assets/MouseFlight/Scripts/MouseFlightController.cs

直接阅读 RotateRig、Damp 和冻结瞄准方向的实现。参考其“相机、瞄准与机体分开”“极点附近使用相机自身向上方向”“指数时间阻尼”的结构。

落地：`src/flight_tools.js` 的 `lookQuaternion`、`src/runtime.js` 的 `cameraUpdate`。V1 使用单位向量线性插值，在恰好反向时可能仍沿原方向；V2 改为四元数球面插值，补足精确 180° 和正上／正下的退化方向处理。相机采用独立姿态，不把飞机的全部滚转强加给第三人称画面。物理机体本身没有被相机反向控制。

## wt-mouse-aim：防振荡、预测包线、接管

核心： https://github.com/cosistra/wt-mouse-aim/blob/6fb450f718d5f9046a56c27061264d345e100654/ChaseController.cs

诊断： https://github.com/cosistra/wt-mouse-aim/blob/6fb450f718d5f9046a56c27061264d345e100654/WOBBLE-FINDINGS.md

结构： https://github.com/cosistra/wt-mouse-aim/blob/6fb450f718d5f9046a56c27061264d345e100654/ARCHITECTURE.md

阅读重点为作者对低动压俯仰振荡、后方目标翻转、垂直航向奇异点、预测迎角门控，以及手动接管的分析。该项目运行于 Nuclear Option 的飞控层之上，其下游通常是飞行包线内的角速度命令；本项目的下游则是舵面及气动力矩，因此不能直接照搬它的增益数值。

落地到 `src/instructor_v2.h`：

| 参考问题 | 本项目的实现 |
|---|---|
| 输出增益与被控对象不匹配 | 由 NF-01 已有力矩系数、惯量和动压计算舵面／角速度转换，建立独立俯仰、滚转、偏航内环 |
| 低速不断加大追踪、反而振荡 | 动压降低时缩减外环角速度要求；不同时削弱测量角速度的阻尼 |
| 大仰角水平航向误差放大 | 水平投影长度作为航向可信度；靠近极点时使用机体坐标中的目标误差 |
| 目标跨越正后方，左右指令翻转 | 后方转向侧承诺与退出阈值，加目标倾侧变化率限制；普通前方转向仍可反向 |
| 迎角到顶才修正 | 测量迎角与载荷变化率，短时预测；保护快介入、缓恢复，控制输入卸载而非裁切物理状态 |
| 小范围误差与持续目标移动混在一起 | 仅在准星近乎静止、误差小、未饱和、未保护时允许微量积分；有积分界限和泄漏 |
| 手动输入与教官争抢 | 整机／分轴接管可选，保持时间可调，保留实际舵面变化率限制 |

这里没有实现原模组的所有内容，尤其不包含直升机、鸭翼输入逆映射、飞行员状态或其运行时游戏探测。

## WASM Flight Lab：数值约定、输入曲线和诊断

物理说明： https://github.com/jFriedli/wasm-flight-lab/blob/7af8db7c236ca99ea44946c570860ae339082f66/PHYSICS.md

仓库： https://github.com/jFriedli/wasm-flight-lab/tree/7af8db7c236ca99ea44946c570860ae339082f66

参考其测量侧导数、过滤与抗积分饱和、输入死区／Expo、物理权威与视图分离、指令／实际角速度对照记录。落地为 `FlightTools.shapeAxis`、固定容量历史缓冲、扩展遥测以及实时诊断图。

其细分翼面局部气流、组件质量、VTOL 和 Rust 内核值得继续借鉴，但**本轮没有把这些尚未做的部分写成已经完成**。NF-01 仍然使用 V1 的聚合升阻力与力矩模型，便于控制律之间做公平的 A/B 测试。

## 实现与授权边界

以上开源项目保留各自作者与许可。本轮没有打包其第三方源码或二进制，包内实现沿用本项目 MIT 许可。代码中的参考注释和固定提交链接不表示本项目是那些作者的官方版本，更不代表 War Thunder 官方控制器。

本次不增加 JSBSim 依赖；第一版所列的高保真动力学候选并未成为本版已集成模块。
