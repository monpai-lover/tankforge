import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {core,runCase,cases,direction,D,error} from './benchmark.mjs';
const root=new URL('../',import.meta.url),c=await core(new URL('assets/flight_core.wasm',root)),v1=await core(new URL('tests/fixtures/v1_core.wasm',root));
const ctx=vm.createContext({Math,Float32Array,Uint32Array,Map,Number,Array,Error,console});
vm.runInContext(fs.readFileSync(new URL('src/gl.js',root),'utf8')+'\n'+fs.readFileSync(new URL('src/flight_tools.js',root),'utf8')+'\nglobalThis.tools=FlightTools;globalThis.ring=FlightRing;globalThis.q=Q;',ctx);
const {tools,ring:Ring,q}=ctx;
function reset(sc=0,profile=1,handoff=0,delay=.22){c.w.configure(0,45,1,6.5,1);c.w.configure_control(profile,handoff,delay,1);c.w.reset(sc);}
function run(t,a=direction(0),manual=[0,0,0],flags=1){for(let n=0;n<Math.round(t*120);n++)c.w.step(1/120,...a,.8,...manual,flags);return c.read()}
const metrics=[];
for(const name of ['turn_10','turn_60','turn_100','turn_175','reversal','rear_marker_jitter','highspeed_fine','crosswind_fine'])test(`paired baseline / refinement: ${name}`,()=>{
 const def=cases.find(x=>x.name===name),a=runCase(v1,def),b=runCase(c,def,1);metrics.push({baseline:a,refined:b});
 assert.equal(b.crashed,false);assert.ok(b.finalError<.5);assert.ok(b.settleSeconds<a.settleSeconds,`${b.settleSeconds} !< ${a.settleSeconds}`);
 if(name==='turn_60'||name==='reversal'||name==='rear_marker_jitter')assert.ok(b.rollReversals<a.rollReversals);
 if(name==='reversal'||name==='rear_marker_jitter')assert.ok(b.peakG<a.peakG);
});
test('V1 A/B mode preserves the original physical state, not a fake comparison',()=>{
 c.w.configure_control(0,0,.22,1);for(const w of [c.w,v1.w]){w.configure(0,45,1,6.5,1);w.reset(0)}
 for(let n=0;n<1200;n++){for(const w of [c.w,v1.w])w.step(1/120,...direction(60),.8,0,0,0,1);if(n%50===0)assert.deepEqual(c.read().slice(0,51),v1.read().slice(0,51));}
});
test('per-axis roll override leaves pitch and yaw instructor authority intact',()=>{reset(0,1,1);let s=run(.5,direction(0),[0,1,0]);assert.ok(s[58]>.999);assert.equal(s[59],0);assert.ok(s[60]>.999);s=run(2.5);assert.ok(s[59]>.999)});
test('global override releases all axes; user-specified hold duration is honored',()=>{reset(0,1,0,.8);run(.2,direction(0),[0,.5,0]);let s=run(.6);assert.ok(s.slice(58,61).every(x=>x<.001));s=run(2);assert.ok(s.slice(58,61).every(x=>x>.99))});
test('handoff and all instructor outputs obey physical servo rate bounds',()=>{reset();let last=c.read();for(let n=0;n<1200;n++){let man=n<70?[1,1,0]:[0,0,0];c.w.step(1/120,...direction(60),.8,...man,1);let s=c.read();[3.5,4,3].forEach((rate,k)=>assert.ok(Math.abs(s[24+k]-last[24+k])<=rate/120+1e-6));last=s;}});
test('dynamic pressure scheduling is lower at low speed, without scaling damping to zero',()=>{reset(2);let low=run(.02)[52];reset(3);let hi=run(.02)[52];assert.ok(low>=.3-1e-6&&low<hi);assert.equal(hi,1)});
test('90 second low-speed capture remains finite, unstalled and stable',()=>{const b=runCase(c,cases.find(x=>x.name==='low_speed_hold'));assert.equal(b.crashed,false);assert.ok(b.peakStall<.1);assert.ok(b.tailErrorRMS<.05);metrics.push({lowSpeed:b})});
test('90 seconds of genuinely low dynamic pressure: speed stays below 70 m/s',()=>{reset(2);let maxSpeed=0,maxStall=0;for(let n=0;n<10800;n++){c.w.step(1/120,...direction(0),.06,0,0,0,1);let s=c.read();maxSpeed=Math.max(maxSpeed,s[13]);maxStall=Math.max(maxStall,s[21]);assert.ok(s.every(Number.isFinite))}const s=c.read();assert.ok(maxSpeed<70);assert.ok(maxStall<.1);assert.equal(s[22],0);assert.ok(error(s,direction(0))<.1);metrics.push({lowDynamicPressure:{seconds:90,throttle:.06,maxSpeed,maxStall,altitude:s[1]}})});
test('near-vertical heading confidence reduces while rate outputs stay finite',()=>{reset(3);run(6,direction(0,82));let s=c.read();assert.ok(s[51]<.25);let maxRate=0;for(let n=0;n<480;n++){c.w.step(1/120,...direction(2*Math.sin(n/35),82),.8,0,0,0,1);s=c.read();maxRate=Math.max(maxRate,Math.abs(s[65]));assert.ok(s.every(Number.isFinite))}assert.ok(maxRate<1.61);assert.equal(s[22],0)});
test('rear marker jitter commits once instead of alternating its turn side',()=>{reset(3);let signs=new Set;for(let n=0;n<240;n++){c.w.step(1/120,...direction(179+2*Math.sin(n/120*13)),.8,0,0,0,1);const sign=c.read()[63];if(sign)signs.add(sign)}assert.equal(signs.size,1)});
test('finite integrator bounds and leakage when the marker moves',()=>{reset();for(let n=0;n<9000;n++){c.w.step(1/120,...direction(2,.8),.8,0,0,0,1);let s=c.read();assert.ok(Math.abs(s[56])<=.01201&&Math.abs(s[57])<=.01601)}let before=c.read();run(4,direction(130,20));let s=c.read();assert.ok(Math.abs(s[56])<.003&&Math.abs(s[57])<.003)});
test('reset clears integrators, predictor history and committed turn',()=>{reset();run(1,direction(179));reset();let s=c.read();assert.equal(s[56],0);assert.equal(s[57],0);assert.equal(s[63],0);assert.ok(s.slice(58,61).every(x=>x===1))});
test('refined configuration rejects non-finite / out-of-range values',()=>{reset();c.w.configure_control(1,1,Infinity,Infinity);let s=run(.01);assert.ok(s.every(Number.isFinite));assert.ok(s[71]<=1.5&&s[72]<=10)});
test('control gain sweep stays finite and captures both left/right demands',()=>{for(const gain of [.5,.8,1.3,1.6])for(const sign of [-1,1]){reset(3);c.w.configure(0,45,gain,6.5,1);let s=run(35,direction(sign*70));assert.equal(s[22],0);assert.ok(error(s,direction(sign*70))<.6)}});
test('input deadzone/expo preserves monotonicity, centre and endpoints',()=>{const f=tools.shapeAxis;assert.equal(f(.1),0);assert.equal(f(-.1),0);assert.equal(f(0),0);assert.equal(f(1),1);assert.equal(f(-1),-1);assert.equal(f(NaN),0);let prev=-1;for(let i=-100;i<=100;i++){let val=f(i/100);assert.ok(val>=prev);prev=val}});
test('antipodal camera turns rather than remaining stuck in normalized-lerp',()=>{let a=tools.lookQuaternion([0,0,1]),b=tools.lookQuaternion([0,0,-1]);let half=q.slerp(a,b,.5),f=q.rot(half,[0,0,1]);assert.ok(Math.abs(f[2])<1e-6);assert.ok(Math.abs(f[0])>.99);let fin=q.rot(q.slerp(a,b,1),[0,0,1]);assert.ok(fin[2]<-.999)});
test('look basis remains normalized at both exact poles',()=>{for(const v of [[0,1,0],[0,-1,0],[.001,1,.001]]){let a=tools.lookQuaternion(v);assert.ok(a.every(Number.isFinite));assert.ok(Math.abs(Math.hypot(...a)-1)<1e-6)}});
test('render interpolation is bounded, quaternion-normalized and never mutates physics',()=>{reset();let a=c.read();run(1);let b=c.read(),aa=a.slice(),bb=b.slice();let r=new Float32Array(80);tools.interpolate(a,b,.5,r);assert.ok(Math.abs(r[2]-(a[2]+b[2])/2)<.001);assert.ok(Math.abs(Math.hypot(...r.slice(3,7))-1)<1e-6);assert.deepEqual(a,aa);assert.deepEqual(b,bb)});
test('ring buffer stays bounded and returns chronological rows after wrap',()=>{let r=new Ring(4);for(let i=0;i<10;i++)r.push(i);assert.equal(r.length,4);assert.deepEqual(Array.from(r.toArray()),[6,7,8,9]);r.clear();assert.equal(r.length,0)});
process.on('exit',()=>fs.writeFileSync(new URL('tests/refinement-comparison.json',root),JSON.stringify({method:'120 Hz; same physical model and scripted inputs. settle=first entry within 0.5 deg followed by 2 continuous seconds. rollReversals=sign changes beyond +/-0.05, not a direct measure of pilot-induced oscillation. Not original-game comparison.',metrics},null,2)));
