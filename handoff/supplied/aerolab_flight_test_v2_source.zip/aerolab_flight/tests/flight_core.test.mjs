import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const bytes=fs.readFileSync(new URL('../assets/flight_core.wasm',import.meta.url));
const {instance}=await WebAssembly.instantiate(bytes,{math:Math});const w=instance.exports;
const state=()=>Array.from(new Float32Array(w.memory.buffer,w.state_ptr(),w.state_len()));
const rad=Math.PI/180;
function reset(sc=0){w.configure(0,45,1,6.5,1);w.reset(sc);}
function run(seconds,aim=[0,.021,1],throttle=.8,flags=1,manual=[0,0,0],observe=null){for(let i=0;i<Math.round(seconds*120);i++){w.step(1/120,...aim,throttle,...manual,flags);if(observe)observe(state())}return state()}
function err(s,a){let n=Math.hypot(...a);return Math.acos(Math.max(-1,Math.min(1,(s[48]*a[0]+s[49]*a[1]+s[50]*a[2])/n)))/rad}
function close(a,b,t=1e-5){assert.ok(Math.abs(a-b)<t,`${a} differs from ${b} by more than ${t}`)}
test('real WASM ABI, bounded linear memory, only math imports',()=>{assert.equal(w.core_version(),200);assert.equal(w.state_len(),80);assert.equal(w.memory.buffer.byteLength,131072);let imports=WebAssembly.Module.imports(new WebAssembly.Module(bytes));assert.ok(imports.length>0);assert.ok(imports.every(x=>x.module==='math'));});
test('all five spawn states are finite and quaternion normalized',()=>{for(let j=0;j<5;j++){reset(j);let s=state();assert.ok(s.every(Number.isFinite));close(Math.hypot(...s.slice(3,7)),1)}});
test('straight flight integrates distance; does not snap or teleport',()=>{reset();let s=run(20);assert.ok(s[2]>-1500);assert.ok(s[13]>90&&s[13]<140);assert.equal(s[22],0);assert.ok(err(s,[0,.021,1])<.1)});
for(let deg of [-100,-60,-30,-10,10,30,60,100])test(`mouse-aim capture ${deg} degrees with bank-and-pull`,()=>{reset();let a=[Math.sin(deg*rad),.021,Math.cos(deg*rad)],peakG=0,peakBank=0;let s=run(24,a,.8,1,[0,0,0],s=>{peakG=Math.max(peakG,s[17]);peakBank=Math.max(peakBank,Math.abs(s[20]));});assert.ok(err(s,a)<.5,`capture residual ${err(s,a)}`);assert.ok(peakBank>8*rad);assert.ok(peakG<8);assert.equal(s[22],0);close(Math.hypot(...s.slice(3,7)),1)});
test('keyboard roll hands off all instructor axes, then eases back',()=>{reset();let s=run(.7,[0,.021,1],.8,1,[0,1,0]);assert.equal(s[28],0);assert.ok(s[20]>12*rad);s=run(2);assert.ok(s[28]>.99)});
test('nose and actual velocity can differ in a turn',()=>{reset();let peak=0;run(5,[Math.sin(60*rad),.021,Math.cos(60*rad)],.8,1,[0,0,0],s=>{let v=s.slice(7,10),n=Math.hypot(...v);peak=Math.max(peak,err(s,v.map(x=>x/n)));});assert.ok(peak>3)});
test('unprotected low-speed pull stalls and loses altitude',()=>{reset(2);w.configure(0,45,1,6.5,0);let peak=0;let s=run(15,[0,.02,1],.1,0,[1,0,0],s=>peak=Math.max(peak,s[21]));assert.ok(peak>.9);assert.ok(s[1]<1650);assert.ok(s.every(Number.isFinite))});
test('AoA protection reduces high-angle stall demand (soft limit)',()=>{reset(2);let peak=0;run(20,[0,.02,1],.8,1,[1,0,0],s=>peak=Math.max(peak,s[21]));assert.ok(peak<.25)});
test('zero-throttle glide loses energy rather than retaining arbitrary speed',()=>{reset();let before=state(),s=run(30,[0,0,1],0);assert.ok(s[13]<before[13]-12);assert.ok(s[1]<before[1])});
test('airbrake affects actual speed',()=>{reset();let normal=run(12,[0,.021,1],.72)[13];reset();let brake=run(12,[0,.021,1],.72,17)[13];assert.ok(brake<normal-12)});
test('crosswind displaces ground track while nose continues tracking',()=>{reset();w.configure(25,45,1,6.5,1);let s=run(30);assert.ok(s[0]>200);assert.ok(err(s,[0,.021,1])<1)});
test('level hold reduces climb residual',()=>{reset();let s=run(50,[0,0,1],.8,33);assert.ok(Math.abs(s[8])<.2,`vertical speed ${s[8]}`);assert.ok(Math.abs(s[1]-720)<5)});
test('runway takeoff uses forces and ground contact',()=>{reset(4);let peak=0;for(let i=0;i<3600;i++){let s=state();w.step(1/120,0,.06,1,1,s[13]>52?.1:0,0,0,12);peak=Math.max(peak,state()[21])}let s=state();assert.equal(s[22],0);assert.ok(s[1]>100);assert.ok(s[2]>-1700);assert.ok(peak<.25)});
test('same fixed-step inputs reproduce the same state',()=>{reset();let a=run(17,[.45,.06,1],.8);reset();let b=run(17,[.45,.06,1],.8);assert.deepEqual(a,b)});
test('NaN and non-finite inputs cannot poison the state',()=>{reset();let a=state();w.step(NaN,0,0,1,.8,0,0,0,1);assert.deepEqual(a,state());w.step(1/120,NaN,Infinity,-Infinity,NaN,NaN,Infinity,-Infinity,1);assert.ok(state().every(Number.isFinite))});
test('ground collision ends simulation without running through terrain',()=>{reset();let s=run(60,[0,-.8,1],.5,1);assert.equal(s[22],1);let frozen=state();run(3);assert.deepEqual(state(),frozen)});
