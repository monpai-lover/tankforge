"""Capture 10 s from the actual V2 WebGL/WASM page at a fixed 120 Hz.
Run: xvfb-run -a python tests/capture_preview.py /mnt/data/aerolab_v2_capture
Frames are encoded with ffmpeg; this is not a realtime performance measurement.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, sys, math
ROOT = Path(__file__).resolve().parents[1]
DEST = Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/aerolab_v2_capture')
DEST.mkdir(parents=True, exist_ok=True)
errors=[]; records=[]; requests=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    page=browser.new_page(viewport={'width':1280,'height':800},device_scale_factor=1)
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.on('request',lambda r: requests.append(r.url))
    page.set_content((ROOT/'index.html').read_text(),wait_until='domcontentloaded')
    page.wait_for_function('window.FlightLab?.ready',timeout=45000)
    page.evaluate("FlightLab.setManualClock(true);FlightLab.configure({profile:1,handoff:0});FlightLab.startBenchmark('turn')")
    # Suppress only the transient UI toast; the canvas and diagnostics are unchanged.
    page.evaluate("document.getElementById('toast').classList.remove('show');FlightLab.render()")
    for frame in range(200):
        state=page.evaluate('FlightLab.advance(1/20)')
        page.screenshot(path=str(DEST/f'frame_{frame:04d}.png'))
        assert not state[22], 'Unexpected crash'
        if frame%20==0:
            records.append({'frame':frame,'time_s':state[23],'speed_mps':state[13],'bank_deg':math.degrees(state[20]),'altitude_m':state[1]})
            print('FRAME',frame,records[-1],flush=True)
    assert not errors,errors
    assert not requests,requests
    assert page.evaluate('FlightLab.getStatus().glError')==0
    report={'core_version':200,'controller':'refined','benchmark':'turn_60','fps':20,'frames':200,'seconds':10,'method':'actual WebGL render; 120 Hz WASM; fixed-step offline capture, NOT hardware FPS','snapshots':records,'errors':errors,'external_requests':requests}
    (DEST/'capture_results.json').write_text(json.dumps(report,indent=2))
    (ROOT/'tests/capture-results.json').write_text(json.dumps(report,indent=2))
    browser.close()
