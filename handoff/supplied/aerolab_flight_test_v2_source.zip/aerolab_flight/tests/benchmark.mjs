import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
export const D=Math.PI/180;
export async function core(path){const {instance}=await WebAssembly.instantiate(fs.readFileSync(path),{math:Math});let w=instance.exports;return {w,read:()=>Array.from(new Float32Array(w.memory.buffer,w.state_ptr(),w.state_len()))};}
export const direction=(h=0,e=1.2)=>[Math.sin(h*D)*Math.cos(e*D),Math.sin(e*D),Math.cos(h*D)*Math.cos(e*D)];
export const error=(s,a)=>Math.acos(Math.max(-1,Math.min(1,s[48]*a[0]+s[49]*a[1]+s[50]*a[2])))/D;
export const cases=[
 ...[-100,-60,-10,10,60,100,175,-175].map(h=>({name:`turn_${h}`,scenario:0,seconds:35,aim:t=>direction(h)})),
 {name:'highspeed_fine',scenario:3,seconds:40,aim:t=>direction(3)},
 {name:'low_speed_hold',scenario:2,seconds:90,aim:t=>direction(0,1.2)},
 {name:'reversal',scenario:3,seconds:40,aim:t=>direction(t<6?60:-60,1.2)},
 {name:'rear_marker_jitter',scenario:3,seconds:30,aim:t=>direction(t<4?179+2*Math.sin(t*13):179,1.2)},
 {name:'vertical_zoom',scenario:3,seconds:22,aim:t=>direction(0,82)},
 {name:'crosswind_fine',scenario:3,wind:25,seconds:40,aim:t=>direction(5)},
];
export function runCase(c,def,advanced=null){let {w,read}=c;w.configure(def.wind||0,45,1,6.5,1);if(w.configure_control)w.configure_control(advanced??1,0,.22,1);w.reset(def.scenario);let peakG=0,peakBank=0,peakStall=0,rollReversals=0,lastSign=0,errList=[],settledStart=null,settledAt=null,n=0,crash=false,maxRollStep=0,lastRoll=0,minSpeed=1e9;
 for(let i=0;i<def.seconds*120;i++){let t=i/120,a=def.aim(t);w.step(1/120,...a,.8,0,0,0,1);let s=read();peakG=Math.max(peakG,s[17]);peakBank=Math.max(peakBank,Math.abs(s[20])/D);peakStall=Math.max(peakStall,s[21]);minSpeed=Math.min(minSpeed,s[13]);maxRollStep=Math.max(maxRollStep,Math.abs(s[25]-lastRoll));lastRoll=s[25];if(i%12===0){let e=error(s,a);errList.push({t,e,roll:s[25],aoa:s[15]/D});if(e<.5){settledStart??=t;if(t-settledStart>=2&&settledAt===null)settledAt=settledStart}else settledStart=null;let sg=Math.abs(s[25])>.05?Math.sign(s[25]):0;if(sg&&lastSign&&sg!==lastSign)rollReversals++;if(sg)lastSign=sg;n++;}if(s[22]){crash=true;break;}}
 let tail=errList.slice(-50),s=read();return {case:def.name,settleSeconds:settledAt===null?null:+settledAt.toFixed(2),tailErrorRMS:+Math.sqrt(tail.reduce((a,x)=>a+x.e*x.e,0)/tail.length).toFixed(4),finalError:+error(s,def.aim(s[23])).toFixed(4),peakG:+peakG.toFixed(3),peakBank:+peakBank.toFixed(2),peakStall:+peakStall.toFixed(3),rollReversals,maxRollStep:+maxRollStep.toFixed(5),minSpeed:+minSpeed.toFixed(2),altitude:+s[1].toFixed(1),crashed:crash};}
if(import.meta.url===pathToFileURL(process.argv[1]).href){let path=process.argv[2]||new URL('../assets/flight_core.wasm',import.meta.url),c=await core(path);let results=cases.map(x=>runCase(c,x));console.log(JSON.stringify(results,null,2));}
