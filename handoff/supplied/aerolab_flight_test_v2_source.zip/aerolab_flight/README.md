# AEROLAB 02 — WebGL 2 + WASM 飞控优化迭代

这是上一版 AEROLAB 01 的直接迭代。新增教官控制律、V1/V2 同物理模型对照、实时诊断、相机退化方向修复与画面插值。**实际内核仍为 C → WebAssembly，不是 Rust。没有合并任何远程游戏仓库，也没有使用原游戏资源。**

## 运行

`index.html` 已内嵌 WASM、JavaScript、界面与程序化素材，无 CDN、外部字体、登录或联网素材。下载即可在支持 WebGL 2 / WASM 的浏览器运行。

文件预览不执行 JavaScript 时，解压后运行 `python3 serve.py --open`。Windows 可以使用 `啟動_Windows.bat`；macOS/Linux 执行 `bash 啟動_Mac_Linux.sh`。脚本需要 Python 3，只监听本机 127.0.0.1。也可把 index.html 部署到自己的静态站点。

按“接管试飞”使用鼠标锁定；Esc 释放。不能锁定时仍可按住画面拖动，手机支持触控拖动。

## 本轮主要变化

**教官：** 根据本机的真实代码系数换算角速度与舵面输出，而不是继续增大跟踪增益。使用机体角速度闭环、低动压需求调节、近垂直方向处理、后方转向侧保持、迎角／过载预测和有界微积分。只是控制输入变化，位置、速度、姿态仍由原来的力／力矩积分产生。

**接管：** 默认整机接管，按住任一舵面键时教官让出三轴；也可选分轴接管，只让出正在操作的轴。松开保持时间可调；之后平滑交还，舵面本身仍有限速。

**相机与流畅度：** 姿态使用四元数插值；修复目标精确反向时归一化向量插值卡住的问题。渲染在相邻两个 120 Hz 物理快照间插值，绝不把渲染结果写回物理。地图约 10 Hz、数值界面约 12.5 Hz 更新；航迹 GPU 缓冲只分配一次，其后更新数据。高频遥测历史采用固定容量环形缓冲，不再反复移动整个历史数组。这些是代码路径改进，不是实机 FPS 提升承诺。

**诊断：** 按 F2 或右上“诊断”，查看准星误差、俯仰目标／实际角速度、分轴教官权重、迎角／过载门控及动压调节。可导出扩展 CSV 或含元数据的 JSON。

## 公平比较 V1 与 V2

打开诊断，选择 V2 或 V1，然后对同一脚本点击“重置并开始”。程序会恢复该情境的相同机体状态，按固定时间下达相同目标方向。V1 分支的前 51 个物理输出已与第一版原始 WASM 作逐位一致测试，而不是另外制作一段看起来更差的动画。

可运行的脚本是 60° 转向、反向转弯、后方目标抖动、90 秒低动压滑翔、12 秒大仰角测试。鼠标或键盘可中止脚本接管。90 秒滑翔使用 6% 油门，会自然失高；不是高度保持或低速爬升。

单独选择“低速恢复”起始情境再加油门，与 90 秒低动压滑翔不是同一项试验。图线最多显示最近 24 秒；CSV 最多保留最近 6 分钟，每秒约 10 行。

## 操作

| 操作 | 功能 |
|---|---|
| 鼠标 / 触控拖动 | 世界空间瞄准方向；金圈为目标、白十字为机头、青色为相对空气速度方向 |
| W / S；A / D；Q / E | 抬头／低头；左右滚转；方向舵 |
| Shift / Ctrl、滚轮、油门滑杆 | 增减油门 |
| C 或右键按住 | 自由观察；仅自由观察不改变准星；自由观察中手动改航向会更新保持方向 |
| I / L | 教官开关／平飞保持 |
| G / F / B | 起落架／襟翼／减速板 |
| V / P / R / F2 | 镜头／暂停／重置／飞控诊断 |

## GitHub 参考具体落点

`RESEARCH.md` 说明实际阅读了哪些源文件、固定提交编号、哪些思想进入本版以及哪些没有实现；`source_references.json` 可供开发工具读取。主参考为 brihernandez/MouseFlight、cosistra/wt-mouse-aim、jFriedli/wasm-flight-lab。不是只引用仓库名，也不是把 Unity 模组直接改后缀成 WASM。

## 测试

`tests/core-results.txt` 是本版实际运行的 49 项内核／工具／对照测试结果；34 项浏览器检查也已通过，结果见 `tests/browser-results.json`。配对指标与方法见 `ITERATION_REPORT.md` 与 `tests/refinement-comparison.json`。

测试涵盖原有试飞功能、接管、包线、输入合法性，加上内置 V1 的原始状态一致性、细微／大幅转向、后方抖动、持续低动压、积分边界、极点相机、反向相机、呈现插值和环形缓冲。浏览器测试使用真实鼠标／键盘／触控事件及真实 WebGL/WASM。

测试环境为 Linux Chromium + ANGLE/SwiftShader。手机尺寸与触控通过模拟环境测试，不等于 iPhone/Safari 真机验证，未连接实体手柄。视频由实际页面固定步长逐帧取图编码，不是实时帧率基准。

## 源码结构与重建

```text
src/flight_core.c          原有飞机动力学 + V1 分支 + WASM ABI
src/instructor_v2.h        新版控制律／接管／门控，便于单独移植
src/flight_tools.js        相机姿态、快照插值、输入曲线、环形历史
src/runtime.js             输入、相机、双版本切换、诊断、渲染循环
src/gl.js                  WebGL 2 及可复用动态缓冲
src/scene.js               原有 NF-01、海岛、航门
assets/flight_core.wasm    已编译的真实 WASM
source_references.json     GitHub 固定提交／blob 元信息
RESEARCH.md                来源到实现的对应关系
ARCHITECTURE.md             ABI、数据索引与接入约定
ITERATION_REPORT.md        本轮 A/B 指标、取舍与限制
```

已编译文件可以直接运行。修改 C 后需要 Clang / wasm-ld 和 Python 3；只改前端不需重新编译内核。

```bash
bash build.sh
# 只打包 JavaScript/HTML：
python3 pack.py
node --test tests/flight_core.test.mjs tests/refinement.test.mjs
xvfb-run -a python tests/browser_regression.py
```

## 边界

NF-01 为虚构机型，仍是游戏测试用的聚合升阻力、简化失速和简化地面接触。没有增加细分翼面气流、尾旋、跨音速、真实发动机曲线、损伤或空战。软包线不能保证所有操作不超限，长期尾冲／极低空速大仰角不属于已经校准的飞行范围。

本轮刻意保留原动力学，以便把控制律改进与物理模型变化分开测量。它不是 War Thunder 的官方飞控或完整一比一模型，也不能用于真实飞行训练。

Rust 接入时可依据 ARCHITECTURE.md 保留意图输入及快照 ABI，再替换实现；当前包没有把尚未编译的 Rust 文件当作正在运行的内核。
