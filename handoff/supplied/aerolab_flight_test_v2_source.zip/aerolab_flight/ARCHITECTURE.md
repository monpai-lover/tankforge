# AEROLAB：資料流、WASM ABI 與整合

## 分層

```text
滑鼠／鍵盤／觸控／手把
  → JS：世界瞄準方向 + 手動意圖 + 油門 + 模式旗標
  → WASM：教官、舵面控制、氣動力／力矩、速度與四元數積分
  → 80 × float32 狀態快照
  → JS：相機、舵面動畫、WebGL 2、HUD、航門計分與本機 CSV
```

本版沒有網路同步。切回既有 Rust 遊戲時，保留固定步進／意圖輸入／輸出快照的分離，避免讓畫面 FPS 直接決定物理速度，也不要同時讓兩套引擎裁定同一架飛機的位置。

機體座標名稱採 +X 右、+Y 上、+Z 機頭。內核以 quaternion/cross-product 的一致約定積分，渲染採與之匹配的 view/projection；整合別的引擎時必須校準基底和旋轉符號，不應只翻轉位置 Z。外部控制約定為 pitch 正值抬頭、roll 正值右機翼下沉、yaw 正值向右。

## WASM 實例化

不依賴 WASI、檔案系統或網路。固定 128 KiB 線性記憶體；JS 供應少數超越函式，其餘狀態更新在 WASM。

```js
const { instance } = await WebAssembly.instantiate(bytes, {
  math: {
    sin: Math.sin, cos: Math.cos, atan2: Math.atan2,
    exp: Math.exp, asin: Math.asin, acos: Math.acos
  }
});
const api = instance.exports;
api.configure_control(1, 0, 0.22, 1); // V2，整机接管
api.reset(0);
api.configure(0, 45, 1, 6.5, 1);
api.step(1 / 120, 0, 0.03, 1, 0.72, 0, 0, 0, 1);
const state = new Float32Array(api.memory.buffer, api.state_ptr(), api.state_len());
```

`step(dt, aimX, aimY, aimZ, throttle, manualPitch, manualRoll, manualYaw, flags)`

方向輸入是世界方向向量；不是空間中的固定目標點。油門允許 0–1.12；手動三軸為 -1–1。`flags` 位元：1 教官、2 自由觀察、4 起落架、8 襟翼、16 減速板、32 平飛保持。模式旗標需由呼叫端持續傳入，不是 toggle 訊息。

`configure(windKnots, flowHeadingDegrees, response, gTarget, protection)`：風場方向為流向，不是氣象「來向」；`gTarget` 是軟控制目標。

`reset(scenario)`：0 巡航、1 進場、2 低速、3 高速、4 跑道。

`terrain_height(x,z)`：共享地形解析函式；高度 < 0 的區域視為海域。

`configure_control(profile, handoffMode, releaseDelaySeconds, returnResponse)`：0=V1，1=V2；handoffMode 0=整机、1=分轴。保持时间内部限制 0–1.5 s，返回系数 0.4–2。切换控制律会清空控制器记忆，不改机体的当前位置、速度和姿态。`core_version()` 为 200。

状态最前面的 0–50 项保留原含义。旧代码不能再硬编码 64，必须用 `state_len()`，当前返回 80。原 V1 模式的前 51 个数在回归测试中与原版 WASM 比较。

## 狀態快照

| Float32 索引 | 內容 |
|---|---|
| 0–2 | 世界位置，m |
| 3–6 | 四元數 x/y/z/w |
| 7–9 | 世界地速向量，m/s |
| 10–12 | 機體角速度，rad/s |
| 13 / 14 | TAS / 簡化 IAS，m/s |
| 15 / 16 / 17 | 迎角 rad / 側滑角 rad / 法向氣動載荷 G |
| 18 / 19 / 20 | 航向 / 俯仰 / 傾側，rad |
| 21 / 22 / 23 | 失速混合程度 / 撞毀旗標 / 模擬時間 s |
| 24–26 | 升降舵／副翼／方向舵控制輸出 |
| 27 / 28 / 29 | 平滑引擎油門 / 教官權重 / 目標傾側 |
| 30–32 | 世界風速向量 |
| 33 / 34 / 35 | 起落架程度 / 襟翼程度 / 距地高 m |
| 36–41 | 控制階段 / 推力 N / 接管保持時間 / 保護 / G 目標 / 風速設定 |
| 42–44 / 45–47 / 48–50 | 機體 right / up / forward 世界基底 |
| 51–57 | 航向可信度 / 动压调节 / AoA 门控 / 目标误差 rad / 目标角速度 rad/s / P、Y 积分 rad/s |
| 58–63 | P/R/Y 教官权重 / 控制律版本 0或1 / G门控 / 后方转向侧 -1,0,1 |
| 64–69 | 目标 P/R/Y 角速度 rad/s / 迎角变化率 rad/s / G变化率 / 航向变化率 rad/s |
| 70–73 | 接管模式 / 松开保持秒 / 返回速率 / 滚转误差 rad |
| 74–79 | 动压 Pa / 地速 m/s / 模拟时间副本 / 保留×3 |

外部如需保存快照必須拷貝，不能長期保留對可變內存的 view 當作歷史記錄。

## 時間與接管

每幀累計時間，內核固定 1/120 秒，最多補 12 步；太慢時丟棄超額牆鐘時間，而不是無限追趕造成卡死。分頁不可見時暫停並清除按鍵，恢復時不追補整段離開時間。相机用指数时间阻尼与四元数球面插值，独立于机体。渲染位置和姿态在前后快照间插值，最多引入一个 1/120 秒的呈现延迟，不回写物理快照。视图 HUD 使用同一个呈现姿态，避免机体与准星插值阶段不一致。

任一手動軸超過閾值時，全軸教官暫讓出控制，再平滑交還；自由觀察時可藉手動操作改變航向，釋放後不強拉回久遠目標。教官保護是軟限制，不能保證所有極端情境都不超 G 或不失速。

## 限定的診斷介面

`window.FlightLab` 可在開發者 console 使用。正常遊玩不經這些測試方法改寫結果。

- `getState() / getAim() / getStatus() / getTelemetry()` 回傳副本。
- `setAim([x,y,z])` 設置有限非零方向並退出展示／平飛保持。
- `reset(0..4)` 重置場景。
- `setMode({paused, demo, instructor, gear, flaps, brake, level, trails, camera, throttle})`。
- `configure({wind,response,gLimit,protection,profile,handoff,releaseDelay})`。
- `advance(seconds, inputs=null)` 最多 120 秒，按 120 Hz 步進並繪製最終畫面。`inputs` 可有 `aim`、`manual`、`throttle`、`flags`；傳 null 保留正常展示航線導航。
- `setManualClock(true)` 僅停下牆鐘自動推進，不偽裝成暫停。用 `advance` 逐幀輸出影片時，HUD 會顯示 OFFLINE CAPTURE；`false` 恢復實時迴圈。

固定輸入在本測試引擎中可重現；沒有保證所有 CPU、JS math 和不同瀏覽器的逐位浮點一致性。若用於競技聯網，需要服務端權威狀態、校正和相應安全邊界。

## V2 诊断与历史缓冲

`startBenchmark("turn"|"reversal"|"rear"|"slow"|"vertical")` 会明确重置试飞状态，然后运行脚本输入。`getBenchmark()` 返回当前或最近完成报告。`getPresentation()` 提供呈现姿态与相机，`setPresentationAlpha(0..1)` 仅用于验证，不改变 `getState()`。

`getTelemetryHeaders()` 与 `getTelemetry()` 对应 41 列。CSV 的新字段使用明确的 rad、rad/s 或无量纲命名；旧字段中的 deg 保持角度。JSON 导出同时包含字段名和配置，避免误读。

动态航迹顶点缓冲容量为 600 顶点，初始化一次，后续 bufferSubData 更新已用区域。遥测环形缓冲容量 3600 行；诊断图历史 240 行。浏览器模块没有新的网络访问或存储权限。
