/* Procedural test aircraft and environment. No proprietary aircraft assets. */
function wing(sign=1,tail=false){
 let p=[],ix=[],sections=tail?[[.20,.00,.9,.045],[1.2,.10,.80,.035],[2.10,.20,.48,.02],[2.25,.25,.12,.006]]:[[.48,.0,2.5,.16],[1.3,.04,2.40,.15],[3.0,.13,2.10,.115],[4.75,.25,1.60,.07],[5.45,.32,1.13,.025],[5.62,.34,.27,.005]];
 let zbase=tail?-3.6:1.05,N=24;
 for(let [x,y,ch,th] of sections)for(let j=0;j<=N;j++){let a=j/N*TAU,cz=(1-Math.cos(a))*.5,z=zbase-(x*.10)-ch*cz;let thick=Math.sin(a)*th*(.70+.30*Math.sin(cz*Math.PI));p.push(x*sign,y+(tail?.42:0)+thick,z)}
 for(let j=0;j<sections.length-1;j++)for(let k=0;k<N;k++){let a=j*(N+1)+k,b=a+N+1;if(sign>0)ix.push(a,b,a+1,a+1,b,b+1);else ix.push(a,a+1,b,a+1,b+1,b)}return mesh(p,ix);
}
function blade(){return faces([[[.10,.15,0],[-.13,.2,0],[-.23,1.4,-.08],[-.12,1.75,-.09],[.13,1.6,.02],[.2,.5,.07]],[[.10,.15,.035],[.2,.5,.105],[.13,1.6,.055],[-.12,1.75,-.055],[-.23,1.4,-.045],[-.13,.2,.035]]]);}
function buildPlane(renderer){
 let b=new Batch,metal='#afb8b6',dark='#263d4a',light='#dde1d9',amber='#e7a943';
 let fus=lathe([[-4.85,.028,.04],[-4.4,.13,.22],[-3.65,.23,.33],[-2.7,.35,.45],[-1.65,.48,.55],[-.6,.61,.61],[.6,.64,.64],[1.65,.60,.61],[2.6,.53,.56],[3.2,.43,.45],[3.45,.33,.34],[3.5,.02,.02]],40);
 b.add(fus,[0,0,0],[1,1,1],metal,3);
 // Dark upper cowling, exhaust stacks and separated cowl bands.
 b.add(lathe([[1.25,.611,.618],[2.64,.54,.568],[3.1,.45,.475]],36),[0,0,0],[1,1,1],dark,3);
 for(let z of [1.29,2.62,3.13])b.add(torus(z>3?.456:z>2?.553:.622,.015,TAU,48,6),[0,0,z],[1,1,1],light,3);
 for(let side of [-1,1]){
  b.add(wing(side),[0,0,0],[1,1,1],metal,3);
  b.add(wing(side,true),[0,0,0],[1,1,1],metal,3);
  for(let z of [1.55,1.85,2.15,2.45])b.rod([side*.53,-.12,z],[side*.71,-.18,z-.10],.072,'#4d4f4a',3);
  b.box([side*2.1,-.26,-.16],[.7,.38,1.03],dark,3);
  // Painted roundels and high-visibility tip strips (fictional test unit).
  b.add(cylinder,[side*3.7,.26,-.5],[.49,.49,.012],dark,0,Q.axis([1,0,0],Math.PI/2));
  b.add(cylinder,[side*3.7,.272,-.5],[.35,.35,.012],light,0,Q.axis([1,0,0],Math.PI/2));
  b.add(cylinder,[side*3.7,.284,-.5],[.17,.17,.012],amber,0,Q.axis([1,0,0],Math.PI/2));
  b.box([side*4.84,.3,-.26],[.18,.045,1.38],amber,0);
  b.ball([side*5.47,.32,-.55],[.08,.045,.06],side<0?'#eb6853':'#7ecab4',5);
  b.box([side*.56,.05,-1.27],[.025,.045,.9],'#555e61',3);
 }
 // Vertical tail and rudder, with a swept leading edge.
 b.add(faces([[[0,.3,-4.65],[0,1.8,-4.2],[0,1.88,-3.88],[0,.5,-3.38]],[[.065,.3,-4.65],[.065,.5,-3.38],[.065,1.88,-3.88],[.065,1.8,-4.2]],[[0,.5,-3.38],[0,1.88,-3.88],[.065,1.88,-3.88],[.065,.5,-3.38]]]),[0,0,0],[1,1,1],dark,3);
 b.box([0,1.41,-4.13],[.085,.12,.57],amber,0);
 // Seat, pilot and canopy frame, all geometry under the glass.
 b.box([0,.4,-.73],[.48,.4,.43],'#222f37');b.box([0,.64,-.92],[.48,.62,.1],dark);
 b.ball([0,.82,-.56],[.24,.32,.20],'#646d68',8);b.ball([0,1.15,-.49],[.16,.20,.16],'#313c40',8);
 b.box([0,1.17,-.355],[.20,.055,.03],'#a0c0c7',8);
 b.box([0,.65,.56],[.50,.3,.11],'#182a34');
 b.rod([-.4,.46,.67],[-.32,1.30,.41],.014,light,3);b.rod([.4,.46,.67],[.32,1.30,.41],.014,light,3);
 b.rod([-.32,1.30,.41],[.32,1.30,.41],.012,light,3);
 for(let z of [-1.24,-.80,.3])for(let k=0;k<12;k++){let a=k/12*Math.PI,aa=(k+1)/12*Math.PI;b.rod([Math.cos(a)*.47,.56+Math.sin(a)*.94,z],[Math.cos(aa)*.47,.56+Math.sin(aa)*.94,z],.012,light,3)}
 b.rod([0,1.50,-1.21],[0,1.50,.3],.013,light,3);
 b.rod([0,.8,-1.65],[0,1.5,-1.67],.025,dark,3);
 b.rod([0,1.5,-1.67],[0,1.82,-3.94],.003,'#424c4d');
 b.add(lathe([[3.44,0],[3.44,.335],[3.70,.27],[3.96,.12],[4.08,0]],32),[0,0,0],[1,1,1],amber,3);
 let body=b.finish(renderer);
 let glassB=new Batch;glassB.add(sphere,[0,.54,-.39],[.48,.95,1.07],'#84a5b1',4,[0,0,0,1],.62);let glass=glassB.finish(renderer);
 let propB=new Batch;for(let k=0;k<3;k++){propB.add(blade(),[0,0,3.53],[1,1,1],dark,3,Q.axis([0,0,1],k*TAU/3));propB.box([Math.sin(-k*TAU/3)*1.62,Math.cos(k*TAU/3)*1.62,3.52],[.18,.16,.07],amber,0,Q.axis([0,0,1],k*TAU/3))}let prop=propB.finish(renderer);
 let discB=new Batch;discB.add(cylinder,[0,0,3.535],[1.76,1.76,.004],'#c4c3b6',0,[0,0,0,1],.105);discB.add(torus(1.66,.045,TAU,72,4),[0,0,3.54],[1,1,1],amber,0,[0,0,0,1],.17);let disc=discB.finish(renderer);
 let controls=[];
 for(let s of [-1,1]){let a=new Batch;a.box([s*1.02,0,-.27],[1.85,.04,.52],metal,3);a.box([s*1.79,0,-.27],[.13,.045,.52],amber);controls.push({parts:a.finish(renderer),p:[s*2.70,.22,-.74],axis:[1,0,0],sign:s,type:'roll'});
 let el=new Batch;el.box([s*.93,0,-.18],[1.65,.032,.36],metal,3);controls.push({parts:el.finish(renderer),p:[s*.15,.51,-4.30],axis:[1,0,0],sign:1,type:'pitch'});
 let gb=new Batch;gb.rod([0,0,0],[s*.06,-1.13,.04],.044,'#aeb7b7',3);gb.rod([s*.22,0,.40],[s*.04,-.79,.06],.028,'#738388',3);gb.add(cylinder,[s*.10,-1.11,.04],[.34,.34,.16],'#252c2c',6,Q.axis([0,1,0],Math.PI/2));gb.add(cylinder,[s*.10,-1.11,.04],[.16,.16,.17],light,3,Q.axis([0,1,0],Math.PI/2));controls.push({parts:gb.finish(renderer),p:[s*1.67,-.29,.1],axis:[0,0,1],sign:s,type:'gear'});
 }
 let rud=new Batch;rud.add(faces([[[0,0,0],[0,1.25,.12],[0,1.10,-.38],[0,.1,-.58]],[[.06,0,0],[.06,.1,-.58],[.06,1.10,-.38],[.06,1.25,.12]]]),[0,0,0],[1,1,1],metal,3);controls.push({parts:rud.finish(renderer),p:[0,.35,-4.2],axis:[0,1,0],sign:1,type:'yaw'});
 let tailGear=new Batch;tailGear.rod([0,0,0],[0,-.45,.06],.025,metal,3);tailGear.add(cylinder,[0,-.45,.06],[.14,.14,.09],'#222d31',6,Q.axis([0,1,0],Math.PI/2));controls.push({parts:tailGear.finish(renderer),p:[0,-.27,-4.22],axis:[1,0,0],sign:1,type:'tailgear'});
 return {body,glass,prop,disc,controls};
}
function buildWorld(renderer,wasm){
 const th=(x,z)=>wasm.terrain_height(x,z),land=[];let p=[],n=[],ix=[],cols=[];
 function patch(x0,x1,z0,z1,nx,nz,skip=false){let pp=[],nn=[],ii=[];for(let j=0;j<=nz;j++)for(let k=0;k<=nx;k++){let x=mix(x0,x1,k/nx),z=mix(z0,z1,j/nz),y=th(x,z);pp.push(x,y,z);nn.push(...V.norm([th(x-10,z)-th(x+10,z),20,th(x,z-10)-th(x,z+10)]))}for(let j=0;j<nz;j++)for(let k=0;k<nx;k++){let x=mix(x0,x1,(k+.5)/nx),z=mix(z0,z1,(j+.5)/nz);if(skip&&x>=-600&&x<=600&&z>=-4000&&z<=400)continue;let a=j*(nx+1)+k;ii.push(a,a+nx+1,a+1,a+1,a+nx+1,a+nx+2)}return {gpu:renderer.upload(mesh(pp,ii,nn)),kind:1,alpha:1,model:M.id()}}
 land.push(patch(-18000,18000,-18000,18000,180,180,true));land.push(patch(-600,600,-4000,400,60,220));
 let oceanB=new Batch;oceanB.box([0,-1,0],[100000,1.7,100000],'#2c708c',2);let ocean=oceanB.finish(renderer);
 let airfieldB=new Batch;
 airfieldB.box([0,22.35,-1450],[56,.25,2400],'#434b4c');
 airfieldB.box([61,22.26,-1380],[38,.2,1900],'#65675e');
 for(let i=0;i<22;i++)airfieldB.box([0,22.50,-2580+i*105],[1.8,.03,38],'#dedbd0');
 for(let x of [-24,24])airfieldB.box([x,22.52,-1450],[.5,.025,2330],'#d9d7c7');
 for(let end of [-2600,-305]){for(let k=0;k<8;k++)airfieldB.box([(k-3.5)*5.1,22.55,end],[2.4,.04,52],'#e9e5d5');airfieldB.box([0,22.57,end+85],[16,.04,6],'#e1ded3')}
 // Taxi links.
 for(let z of [-2310,-680])airfieldB.box([46,22.3,z],[85,.15,25],'#5d625b');
 for(let z=-2500;z< -240;z+=120)for(let x of [-32,32])airfieldB.ball([x,23,z],[.65,.6,.65],'#e3ddbd',5);
 let buildings=new Batch;
 for(let i=0;i<5;i++){let x=155,z=-2300+i*240,y=th(x,z);buildings.box([x,y+1,z],[105,3,142],'#8b8c7d');buildings.box([x,y+17,z],[72,32,92],'#b3b2a5');buildings.box([x,y+34,z],[77,4,98],'#ced1c7');buildings.box([x-36.3,y+11,z],[.7,22,67],'#3c4e53');for(let k=-3;k<=3;k++)buildings.box([x-36.9,y+12,z+k*10],[.5,20,.6],'#818e8c');}
 let tx=115,tz=-1010,ty=th(tx,tz);buildings.box([tx,ty+24,tz],[16,48,19],'#cac9b5');buildings.box([tx,ty+52,tz],[27,10,30],'#46626b');buildings.box([tx,ty+58,tz],[30,3,33],'#e3dfca');buildings.rod([tx,ty+59,tz],[tx,ty+80,tz],.65,'#4d6669');buildings.ball([tx,ty+81,tz],[1.2,1.2,1.2],'#efa975',5);
 // Seeded forests. One batched mesh, no tree draw call per instance.
 let seed=1948;const rand=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return (seed>>>0)/4294967296};
 let trees=new Batch,cone=lathe([[-.5,.75],[.05,.66],[.65,0]],7);
 for(let i=0;i<2400;i++){let x=rand()*19000-9000,z=rand()*17500-4800,y=th(x,z);if(y<32||y>610||(Math.abs(x)<400&&z> -4300&&z<700))continue;let scale=7+rand()*9;let tint=rand(),c=[.055+tint*.014,.095+tint*.055,.063+tint*.025];trees.add(cone,[x,y+scale*.45,z],[scale*.42,scale*.42,scale],c,0,Q.axis([1,0,0],-Math.PI/2));trees.add(cone,[x,y+scale*.8,z],[scale*.3,scale*.3,scale*.72],c,0,Q.axis([1,0,0],-Math.PI/2));}
 // Shoreline rocks and distant sheds give low-altitude parallax.
 let rocks=new Batch,rock=lathe([[-.5,0],[-.35,.7],[.15,1],[.48,.6],[.6,0]],7);
 for(let i=0;i<330;i++){let x=rand()*15000-6500,z=rand()*12000-4500,y=th(x,z);if(y< -2||y>35)continue;let s=2+rand()*6;rocks.add(rock,[x,y+s*.25,z],[s,s*.7,s], '#9a9b88',0,Q.axis([1,0,0],-Math.PI/2))}
 const gates=[ [0,735,-2400],[130,755,-1100],[780,785,130],[1960,815,950],[3200,875,1670],[3900,910,3000],[3520,860,4570],[2250,810,5400],[760,790,4800],[-650,805,3900],[-1080,845,2300],[-780,805,730],[-280,765,-910] ];
 let active=new Batch,passive=new Batch;active.add(torus(86,1.8,TAU,96,8),[0,0,0],[1,1,1],'#dfb66d',5,[0,0,0,1],.90);passive.add(torus(86,.75,TAU,96,6),[0,0,0],[1,1,1],'#b3d2cd',5,[0,0,0,1],.26);
 for(let k=0;k<4;k++){let a=k*Math.PI/2;active.box([Math.cos(a)*86,Math.sin(a)*86,0],[k%2?13:3,k%2?3:13,3],'#f4e5b8',5)}
 const activeGate=active.finish(renderer),passiveGate=passive.finish(renderer);
 return {land,ocean,airfield:airfieldB.finish(renderer),buildings:buildings.finish(renderer),trees:trees.finish(renderer),rocks:rocks.finish(renderer),gates,activeGate,passiveGate,terrain:th};
}
