(async()=>{
const $=id=>document.getElementById(id),canvas=$('world'),hc=$('hud'),ctx=hc.getContext('2d'),mapCtx=$('map').getContext('2d');
function fatal(e){console.error(e);$('fatal').hidden=false;$('fatal').textContent='飛行測試無法啟動\n\n'+(e?.message||e)+'\n\n請使用支援 WebGL 2 與 WebAssembly 的桌面瀏覽器；單文件亦可放到靜態網站。';$('boot').classList.add('ready')}
try{
 const bytes=Uint8Array.from(atob(WASM_BASE64),c=>c.charCodeAt(0));
 const {instance}=await WebAssembly.instantiate(bytes,{math:{sin:Math.sin,cos:Math.cos,atan2:Math.atan2,exp:Math.exp,asin:Math.asin,acos:Math.acos}}),wasm=instance.exports;
 const read=()=>new Float32Array(wasm.memory.buffer,wasm.state_ptr(),wasm.state_len());
 let S=new Float32Array(wasm.state_len()),prev=new Float32Array(wasm.state_len()),R=new Float32Array(wasm.state_len());wasm.reset(0);S.set(read());prev.set(S);
 $('boot-note').textContent='生成海岸試飛場與 NF-01 測試機';await new Promise(requestAnimationFrame);
 const renderer=new Renderer(canvas),plane=buildPlane(renderer),world=buildWorld(renderer,wasm);
 const cfg={wind:0,response:1,gLimit:6.5,sensitivity:1,protection:true,profile:1,handoff:0,releaseDelay:.22,deadzone:.12,expo:.35},state={started:false,demo:true,paused:false,instructor:true,level:false,gear:false,flaps:false,brake:false,camera:0,trails:true,quality:1,scenario:0,throttle:.72,free:false};
 let aim=[0,.021,1];aim=V.norm(aim);let cameraQ=FlightTools.lookQuaternion(aim),cameraDir=aim.slice(),camEye=[0,727,-3678],camTarget=[0,725,-3100],camUp=[0,1,0],freeYaw=0,freePitch=0;
 let keys=new Set,dragging=false,lastPointer=null,freeMouse=false,gate=0,gatesPassed=0,lap=1,telemetry=new FlightRing(3600),trailL=[],trailR=[],trailGpu=null;
 let width=innerWidth,height=innerHeight,mouseLocked=false,lastFrame=performance.now(),acc=0,uiClock=0,mapClock=0,logClock=0,trailClock=0,fps=60,frames=0,clockStart=performance.now(),toastTimer,pausedByVisibility=false,disposed=false,drawDirty=true,manualClock=false;
 let bench=null,benchReport=null,diagHistory=new FlightRing(240),lastUi=-1e9,lastMap=-1e9,uiUpdates=0,mapUpdates=0,renderAlpha=1;
 let lastGateSide=null,missTimer=0,latestAimError=0,soundCtx=null,soundOsc=[],soundGain=null,soundOn=false;
 const FIXED=1/120;
 function toast(s){$('toast').textContent=s;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),3000)}
 function configure(){wasm.configure(cfg.wind,45,cfg.response,cfg.gLimit,cfg.protection?1:0);wasm.configure_control(cfg.profile,cfg.handoff,cfg.releaseDelay,1);drawDirty=true}
 function reset(scenario=state.scenario){
  bench=null;benchReport=null;diagHistory.clear();
  state.scenario=clamp(Math.round(scenario),0,4);state.level=false;state.brake=false;state.gear=state.scenario===1||state.scenario===4;state.flaps=state.scenario===4;state.paused=false;acc=0;
  state.throttle=[.72,.48,.30,.90,.05][state.scenario];wasm.reset(state.scenario);configure();S.set(read());prev.set(S);aim=V.norm([S[48],S[49],S[50]]);cameraDir=aim.slice();cameraQ=FlightTools.lookQuaternion(aim);camEye=V.add(S.slice(0,3),V.add(V.mul(aim,-29),[0,7,0]));camTarget=V.add(S.slice(0,3),V.mul(aim,400));camUp=[0,1,0];freeYaw=freePitch=0;keys.clear();gate=0;gatesPassed=0;lap=1;lastGateSide=null;missTimer=0;telemetry.clear();trailL=[];trailR=[];logClock=trailClock=0;
  clearTimeout(toastTimer);$('toast').classList.remove('show');$('crash').hidden=true;$('throttle').value=Math.round(state.throttle*100);$('scenario').value=String(state.scenario);$('pause').textContent='暫停';syncButtons();drawDirty=true;
 }
 function syncButtons(){for(let [id,on] of [['instructor',state.instructor],['demo',state.demo],['level',state.level],['gear',state.gear],['flaps',state.flaps],['airbrake',state.brake],['trails',state.trails],['protection',cfg.protection]])$(id).classList.toggle('on',on);$('instructor').textContent='教官 '+(state.instructor?'開':'關');$('camera').textContent=state.camera?'機內視角':'追蹤視角';$('pause').textContent=state.paused?'繼續':'暫停';$('demo').textContent=state.demo?'展示航線':'展示 關';$('mode-badge').textContent=state.demo?'展示飛行中 · 點擊「接管試飛」操作':mouseLocked?'滑鼠已鎖定 · Esc 釋放 · C 自由觀察':'按住畫面拖曳瞄準 · 點擊鎖定滑鼠';$('take-control').textContent=mouseLocked?'釋放滑鼠 Esc':'接管試飛 ↗'}
 function setDemo(value){state.demo=!!value;if(state.demo){state.instructor=true;state.level=false;state.scenario=0;reset(0);toast('展示航線：教官追蹤航門，仍由 WASM 物理飛行')}else aim=V.norm([S[48],S[49],S[50]]);syncButtons()}
 function releaseKeys(){keys.clear();dragging=false;freeMouse=false;state.free=false}
 function lockMouse(){state.started=true;if(state.demo){state.demo=false;aim=V.norm([S[48],S[49],S[50]]);syncButtons()}if(mouseLocked){document.exitPointerLock?.();return}try{let p=canvas.requestPointerLock?.();if(p?.catch)p.catch(()=>toast('未獲准鎖定滑鼠，仍可按住畫面拖曳瞄準'));if(!canvas.requestPointerLock)toast('按住畫面拖曳瞄準')}catch{toast('按住畫面拖曳瞄準')}drawDirty=true}
 function updateAim(dx,dy){
   if(state.paused)return;
   if(bench){bench=null;toast("已由滑鼠接管，停止腳本測試")}
   let gain=.0017*cfg.sensitivity;
   if(state.free){freeYaw+=dx*gain;freePitch=clamp(freePitch-dy*gain,-1.35,1.35);return}
   state.level=false;if(state.demo){state.demo=false;syncButtons()}
   let up=renderer.viewUp||[0,1,0],right=renderer.viewRight||[1,0,0];
   aim=V.norm(Q.rot(Q.axis(right,dy*gain),Q.rot(Q.axis(up,dx*gain),aim)));
   drawDirty=true;
 }
 function flightInputs(){let p=(keys.has('KeyW')||keys.has('ArrowDown')?1:0)-(keys.has('KeyS')||keys.has('ArrowUp')?1:0),r=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0),y=(keys.has('KeyE')?1:0)-(keys.has('KeyQ')?1:0);
  // Gamepad is opt-in: the first meaningful axis movement takes manual control.
  let pads=navigator.getGamepads?.()||[];for(let gp of pads){if(!gp)continue;const dz=x=>FlightTools.shapeAxis(x,cfg.deadzone,cfg.expo);let gr=dz(gp.axes[0]||0),gpitch=-dz(gp.axes[1]||0),gy=dz(gp.axes[2]||0);if(Math.abs(gr)+Math.abs(gpitch)+Math.abs(gy)>.02){r=gr;p=gpitch;y=gy;state.demo=false}break}
  return [p,r,y];
 }
 function stepOnce(dt,overrides=null){
  prev.set(S);let inp=overrides?.manual||flightInputs();state.free=keys.has('KeyC')||freeMouse;
  let manual=inp.some(v=>Math.abs(v)>.02);if(manual&&state.demo){state.demo=false;syncButtons()}if(manual){state.level=false;bench=null;}
  if((keys.has('ShiftLeft')||keys.has('ShiftRight'))&&!overrides)state.throttle=clamp(state.throttle+dt*.25,0,1.12);
  if((keys.has('ControlLeft')||keys.has('ControlRight'))&&!overrides)state.throttle=clamp(state.throttle-dt*.25,0,1.12);
  if(state.free&&manual)aim=V.norm([S[48],S[49],S[50]]);
  if(bench&&!overrides){aim=FlightTools.scenarios[bench.kind].aim(bench.elapsed);state.throttle=FlightTools.scenarios[bench.kind].throttle??.8;state.instructor=true;}
  if(state.demo&&!overrides){
    let to=V.sub(world.gates[gate],S.slice(0,3)),vdir=V.norm(S.slice(7,10));
    // Predictive guidance; compensates lateral velocity without altering the aircraft state.
    let desired=V.norm(to),drift=V.sub(vdir,[S[48],S[49],S[50]]);
    let target=V.norm(V.sub(desired,V.mul(drift,.42)));
    aim=V.norm(V.lerp(aim,target,1-Math.exp(-dt*1.8)));
    state.throttle=.78;state.gear=false;state.flaps=false;state.brake=false;
  }
  let a=overrides?.aim?V.norm(overrides.aim):aim;
  let flags=(state.instructor?1:0)|(state.free?2:0)|(state.gear?4:0)|(state.flaps?8:0)|(state.brake?16:0)|(state.level?32:0);
  if(overrides?.flags!==undefined)flags=overrides.flags;
  wasm.step(dt,...a,overrides?.throttle??state.throttle,...inp,flags);S.set(read());
  if(bench){bench.elapsed+=dt;const error=Math.acos(clamp(V.dot(a,S.slice(48,51)),-1,1))/DEG;bench.peakG=Math.max(bench.peakG,S[17]);if(error<.5){bench.dwell+=dt;if(bench.dwell>=2&&bench.settle===null)bench.settle=bench.elapsed-bench.dwell}else bench.dwell=0;
   const sign=Math.abs(S[25])>.05?Math.sign(S[25]):0;if(sign&&bench.lastSign&&sign!==bench.lastSign)bench.reversals++;if(sign)bench.lastSign=sign;
   if(bench.elapsed>=FlightTools.scenarios[bench.kind].duration||S[22]){benchReport={...bench,finalError:error,crashed:!!S[22]};bench=null;state.paused=true;syncButtons();toast('腳本測試結束，可匯出診斷報告');drawDirty=true;}
  }
  if(S[22]){if($('crash').hidden){$('crash').hidden=false;document.exitPointerLock?.();releaseKeys()}return}
  let center=world.gates[gate],before=prev.slice(0,3),after=S.slice(0,3),delta=V.sub(after,before);
  let from=gate?world.gates[gate-1]:[0,720,-3650],normal=V.norm(V.sub(center,from));
  let d0=V.dot(V.sub(before,center),normal),d1=V.dot(V.sub(after,center),normal);
  let crossed=d0<=0&&d1>0,intersection=V.add(before,V.mul(delta,crossed?-d0/(d1-d0):0));
  if(crossed&&V.len(V.sub(center,intersection))<84){gatesPassed++;gate=(gate+1)%world.gates.length;if(gate===0)lap++;lastGateSide=null;missTimer=0;toast('通過航門 '+String(gatesPassed).padStart(2,'0')+' / 航圈 '+lap)}
  else if(state.demo&&V.dot(V.sub(center,after),S.slice(48,51))< -150){missTimer+=dt;if(missTimer>5){gate=(gate+1)%world.gates.length;missTimer=0;toast('展示略過錯過的航門；通過數不增加')}}
  logClock+=dt;if(logClock>=.1){logClock-=.1;telemetry.push([S[23],...S.slice(0,3),S[14]*3.6,S[13]*3.6,S[18]/DEG,S[19]/DEG,S[20]/DEG,S[15]/DEG,S[16]/DEG,S[17],...S.slice(24,29),state.throttle,...S.slice(51,74)]);diagHistory.push([S[23],Math.acos(clamp(V.dot(a,S.slice(48,51)),-1,1))/DEG,-S[10]/DEG,S[64]/DEG,S[25],S[53],S[62]])}
  trailClock+=dt;if(trailClock>=.07){trailClock-=.07;let q=Array.from(S.slice(3,7)),pos=Array.from(S.slice(0,3));trailL.push(V.add(pos,Q.rot(q,[-5.40,.31,-.8])));trailR.push(V.add(pos,Q.rot(q,[5.40,.31,-.8])));if(trailL.length>75){trailL.shift();trailR.shift()}}
 }
 function cameraUpdate(dt,blend=1){
  renderAlpha=clamp(blend);FlightTools.interpolate(prev,S,renderAlpha,R);
  let pos=Array.from(R.slice(0,3)),q=Array.from(R.slice(3,7)),f=Q.rot(q,[0,0,1]);
  if(!state.free){freeYaw*=Math.exp(-dt*4.8);freePitch*=Math.exp(-dt*4.8)}
  let wanted=state.camera?V.norm(V.lerp(f,aim,.34)):aim;
  let seedUp=Math.abs(wanted[1])>.88?Q.rot(cameraQ,[0,1,0]):[0,1,0];
  cameraQ=Q.slerp(cameraQ,FlightTools.lookQuaternion(wanted,seedUp),1-Math.exp(-dt*(state.camera?9:4.1)));
  cameraDir=Q.rot(cameraQ,[0,0,1]);
  const right=Q.rot(cameraQ,[1,0,0]),freeQ=Q.mul(Q.axis(right,-freePitch),Q.axis([0,1,0],freeYaw));
  const dir=Q.rot(freeQ,cameraDir);
  let up=Q.rot(freeQ,Q.rot(cameraQ,[0,1,0])),e,target;
  if(state.camera){e=V.add(pos,Q.rot(q,[0,1.15,-.40]));target=V.add(e,V.mul(dir,600));up=Q.rot(q,[0,1,0]);}
  else {let speedZoom=clamp((S[13]-110)/110,0,.3),distance=25*(1+speedZoom);e=V.add(pos,V.add(V.mul(dir,-distance),[0,4.7,0]));target=V.add(pos,V.add(V.mul(dir,400),[0,2.5,0]));e[1]=Math.max(e[1],world.terrain(e[0],e[2])+2.5,2.5)}
  camEye=e;camTarget=target;camUp=up;
 }
 const trailVertices=new Float32Array(600*9),trailIndices=new Uint32Array(900);
 for(let q=0;q<150;q++){let v=q*4;trailIndices.set([v,v+1,v+2,v+2,v+1,v+3],q*6)}
 function drawTrails(){
  if(!state.trails||trailL.length<3||state.camera)return;
  let cursor=0,segments=0,cnt=trailL.length;
  for(let list of [trailL,trailR])for(let i=1;i<list.length;i++){
   let a=list[i-1],b=list[i],view=V.norm(V.sub(camEye,b)),side=V.mul(V.norm(V.cross(V.sub(b,a),view)),.10+(cnt-i)*.0025);
   for(let pt of [V.sub(a,side),V.add(a,side),V.sub(b,side),V.add(b,side)]){trailVertices.set(pt,cursor);trailVertices.set([0,1,0,.77,.86,.84],cursor+3);cursor+=9}segments++;
  }
  if(!trailGpu)trailGpu=renderer.createDynamic(600,trailIndices);
  renderer.updateDynamic(trailGpu,trailVertices,cursor,segments*6);
  renderer.draw({gpu:trailGpu,model:M.id(),kind:7,alpha:clamp(.12+Math.abs(S[17]-1)*.085,.12,.42)});
 }
 function render(){
  renderer.resize(width,height,state.quality);
  let cam={eye:camEye,target:camTarget,up:camUp,fov:(state.camera?73:61)*DEG,near:state.camera?.08:.25};renderer.begin(cam,R[23]);
  renderer.group(world.land);renderer.group(world.ocean);renderer.group(world.airfield);renderer.group(world.buildings);renderer.group(world.trees);renderer.group(world.rocks);
  for(let i=0;i<world.gates.length;i++){
    let p=world.gates[i],from=i?world.gates[i-1]:[0,720,-3650],dir=V.norm(V.sub(p,from));let yaw=Math.atan2(dir[0],dir[2]);
    let root=M.trs(p,Q.axis([0,1,0],yaw));renderer.group(i===gate?world.activeGate:world.passiveGate,root);
  }
  let root=M.trs(Array.from(R.slice(0,3)),Array.from(R.slice(3,7)));
  renderer.group(state.camera?plane.body.filter(p=>p.kind!==8):plane.body,root);
  for(let o of plane.controls){if((o.type==='gear'||o.type==='tailgear')&&S[33]<.02)continue;let angle=o.type==='roll'?S[25]*o.sign*.38:o.type==='pitch'?S[24]*.42:o.type==='yaw'?S[26]*.40:o.type==='gear'?(1-S[33])*o.sign*-1.51:(1-S[33])*-1.50;renderer.group(o.parts,M.mul(root,M.trs(o.p,Q.axis(o.axis,angle))))}
  let spin=R[23]*(47+S[27]*91),propAlpha=mix(1,.15,smooth(.08,.40,S[27]));for(let p of plane.prop)p.alpha=propAlpha;renderer.group(plane.prop,M.mul(root,M.trs([0,0,0],Q.axis([0,0,1],spin))));if(S[27]>.08){renderer.group(plane.prop,M.mul(root,M.trs([0,0,0],Q.axis([0,0,1],spin+.57))));renderer.group(plane.disc,root);}
  if(!state.camera)renderer.group(plane.glass,root);
  drawTrails();drawHUD();const now=performance.now();
  if(drawDirty||manualClock||state.paused||now-lastMap>=100){drawMap();lastMap=now;mapUpdates++}
  if(drawDirty||manualClock||state.paused||now-lastUi>=80){updateUI();drawDiagnostics();updateSound();lastUi=now;uiUpdates++}
  drawDirty=false;
 }
 function line(a,b){ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke()}
 function label(txt,x,y,align='center',fill='#f0ede0',size=9){ctx.font=`${size}px ui-monospace,Consolas,monospace`;ctx.textAlign=align;ctx.fillStyle=fill;ctx.fillText(txt,x,y)}
 function circle(x,y,r){ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.stroke()}
 function drawHUD(){let d=Math.min(devicePixelRatio||1,2);if(hc.width!==Math.round(width*d)||hc.height!==Math.round(height*d)){hc.width=Math.round(width*d);hc.height=Math.round(height*d)}ctx.setTransform(d,0,0,d,0,0);ctx.clearRect(0,0,width,height);ctx.lineWidth=1;ctx.shadowColor='#132d39df';ctx.shadowBlur=3;
   const pos=Array.from(R.slice(0,3)),f=R.slice(48,51),vdir=V.norm(V.sub(S.slice(7,10),S.slice(30,33)));
   let ap=renderer.project(V.add(pos,V.mul(aim,1600)),width,height),np=renderer.project(V.add(pos,V.mul(f,1600)),width,height),vp=renderer.project(V.add(pos,V.mul(vdir,1600)),width,height);
   latestAimError=Math.acos(clamp(V.dot(aim,f),-1,1))/DEG;
   // The compass tracks the view, not the airframe, so free-look does not falsify aircraft heading.
   let viewHeading=Math.atan2(renderer.viewForward[0],renderer.viewForward[2])/DEG,compY=width<700?70:82,compWidth=Math.min(width*.45,420);
   ctx.save();ctx.beginPath();ctx.rect(width/2-compWidth/2,compY-15,compWidth,44);ctx.clip();
   for(let h=-540;h<=720;h+=10){let delta=h-viewHeading;if(Math.abs(delta)>65)continue;let x=width/2+delta*4;ctx.strokeStyle='#edf0de75';line([x,compY],[x,compY+(h%30===0?7:4)]);if(h%30===0){let hh=(h%360+360)%360;label(hh===0?'N':hh===90?'E':hh===180?'S':hh===270?'W':String(hh).padStart(3,'0'),x,compY-5,'center','#e8eddf',8)}}
   ctx.restore();ctx.fillStyle='#efd39b';ctx.beginPath();ctx.moveTo(width/2-3,compY+12);ctx.lineTo(width/2+3,compY+12);ctx.lineTo(width/2,compY+7);ctx.fill();
   // A restrained pitch ladder; only near-centre segments are displayed.
   let hh=Math.atan2(renderer.viewForward[0],renderer.viewForward[2]);
   ctx.save();ctx.beginPath();ctx.rect(width*.25,height*.22,width*.5,height*.43);ctx.clip();
   for(let deg=-30;deg<=50;deg+=10){let a=deg*DEG,dd=[Math.sin(hh)*Math.cos(a),Math.sin(a),Math.cos(hh)*Math.cos(a)],pp=renderer.project(V.add(camEye,V.mul(dd,2500)),width,height);if(!pp.front||pp.y<height*.23||pp.y>height*.64)continue;ctx.strokeStyle=deg===0?'#ebead672':'#e2eadd32';let ln=deg===0?42:23;line([pp.x-32-ln,pp.y],[pp.x-32,pp.y]);line([pp.x+32,pp.y],[pp.x+32+ln,pp.y]);if(deg!==0)label(String(deg),pp.x+62,pp.y+3,'left','#d9e5e075',8)}ctx.restore();
   if(ap&&np&&ap.front&&np.front&&latestAimError>1.9){ctx.setLineDash([2,7]);ctx.strokeStyle='#efe4c46b';line([ap.x,ap.y],[np.x,np.y]);ctx.setLineDash([])}
   if(vp?.front&&vp.x>10&&vp.x<width-10&&vp.y>80&&vp.y<height-80){ctx.strokeStyle='#a1dfd3';circle(vp.x,vp.y,6.5);line([vp.x-17,vp.y],[vp.x-6.5,vp.y]);line([vp.x+6.5,vp.y],[vp.x+17,vp.y]);line([vp.x,vp.y-13],[vp.x,vp.y-6.5]);if(width>700)label('VECTOR',vp.x,vp.y+24,'center','#b2dfd5',7)}
   if(np?.front&&np.x>0&&np.x<width&&np.y>60&&np.y<height-80){ctx.strokeStyle='#f7f3e6';circle(np.x,np.y,2);for(let a=0;a<4;a++){let co=Math.cos(a*Math.PI/2),si=Math.sin(a*Math.PI/2);line([np.x+co*6,np.y+si*6],[np.x+co*13,np.y+si*13])}}
   if(ap){let visible=ap.front&&ap.x>35&&ap.x<width-35&&ap.y>85&&ap.y<height-100,x=visible?ap.x:clamp(ap.x,37,width-37),y=visible?ap.y:clamp(ap.y,110,height-135);if(!ap.front){x=width-x;y=height-y}ctx.strokeStyle='#f3d59c';ctx.lineWidth=1.35;let rad=width<700?15:19;circle(x,y,rad);ctx.lineWidth=1;for(let a=0;a<4;a++){let co=Math.cos(a*Math.PI/2),si=Math.sin(a*Math.PI/2);line([x+co*(rad+3),y+si*(rad+3)],[x+co*(rad+6),y+si*(rad+6)])}if(width>700)label(visible?'AIM':'AIM ↗',x,y-rad-12,'center','#f1d49d',8)}
   let gp=renderer.project(world.gates[gate],width,height);if(gp?.front&&gp.x>45&&gp.x<width-45&&gp.y>100&&gp.y<height-130){let dist=V.len(V.sub(world.gates[gate],pos)),r=clamp(86/dist*height*.8,8,90);label('GATE '+String(gate+1).padStart(2,'0'),gp.x,gp.y-r-17,'center','#f1d7a6',8);label((dist/1000).toFixed(2)+' km',gp.x,gp.y-r-5,'center','#d6e2df',7)}
   // Bank scale shows airframe bank even while the chase camera stays horizon-level.
   if(width>700){let x=width/2,y=height-152;ctx.strokeStyle='#e0e7db60';ctx.beginPath();ctx.arc(x,y,62,Math.PI*1.13,Math.PI*1.87);ctx.stroke();for(let b of [-60,-30,0,30,60]){let a=(-90+b)*DEG;line([x+Math.cos(a)*58,y+Math.sin(a)*58],[x+Math.cos(a)*64,y+Math.sin(a)*64])}let a=(-90+clamp(S[20]/DEG,-70,70))*DEG;ctx.fillStyle='#eacf9b';ctx.beginPath();ctx.arc(x+Math.cos(a)*62,y+Math.sin(a)*62,2.5,0,TAU);ctx.fill()}
   if(state.free)label('FREE LOOK / 目標方向保持',width/2,height*.76,'center','#f3dbb1',10);
   if(state.paused){label('Ⅱ PAUSED',width/2,compY+28,'center','#f2dfb4',10)}
   ctx.shadowBlur=0;
 }
 const mapBackground=document.createElement('canvas');mapBackground.width=mapBackground.height=256;
 {let mctx=mapBackground.getContext('2d'),img=mctx.createImageData(256,256);for(let y=0;y<256;y++)for(let x=0;x<256;x++){let wx=(x/255)*17000-7500,wz=11500-y/255*17000,h=world.terrain(wx,wz),c=h<0?[26,59,73]:h<15?[120,134,119]:[63+h*.055,90+h*.045,85+h*.03];let k=(y*256+x)*4;img.data[k]=c[0];img.data[k+1]=c[1];img.data[k+2]=c[2];img.data[k+3]=255}mctx.putImageData(img,0,0)}
 function drawMap(){let c=mapCtx,w=296,h=290,pt=p=>[(p[0]+7500)/17000*w,(11500-p[2])/17000*h];c.clearRect(0,0,w,h);c.drawImage(mapBackground,0,0,w,h);c.strokeStyle='#bdcec725';c.lineWidth=1;for(let i=1;i<4;i++){c.beginPath();c.moveTo(i*w/4,0);c.lineTo(i*w/4,h);c.moveTo(0,i*h/4);c.lineTo(w,i*h/4);c.stroke()}c.strokeStyle='#b4c8c376';c.beginPath();world.gates.forEach((p,i)=>{let a=pt(p);i?c.lineTo(...a):c.moveTo(...a)});c.stroke();let a=pt(world.gates[gate]);c.strokeStyle='#efd099';c.lineWidth=2;c.beginPath();c.arc(...a,6,0,TAU);c.stroke();let r=pt([0,0,-1450]);c.strokeStyle='#e4e0c8';c.lineWidth=3;c.beginPath();c.moveTo(r[0],r[1]-15);c.lineTo(r[0],r[1]+15);c.stroke();let pl=pt([S[0],0,S[2]]);c.save();c.translate(...pl);c.rotate(S[18]);c.fillStyle='#fae4b7';c.beginPath();c.moveTo(0,-8);c.lineTo(5,6);c.lineTo(0,3);c.lineTo(-5,6);c.closePath();c.fill();c.restore();c.font='13px sans-serif';c.fillStyle='#ceded6';c.fillText('N',w-19,20)}
 function updateUI(){
  $('ias').textContent=Math.round(S[14]*3.6).toString().padStart(3,'0');$('tas').textContent=Math.round(S[13]*3.6)+' km/h';$('altitude').textContent=Math.round(S[1]).toLocaleString('en-US');$('agl').textContent=Math.round(S[35])+' m';$('vs').textContent=(S[8]>=0?'+':'')+S[8].toFixed(1)+' m/s';$('gload').textContent=S[17].toFixed(1)+' G';$('aoa').textContent=(S[15]/DEG).toFixed(1)+'°';$('aim-error').textContent=latestAimError.toFixed(1)+'°';$('throttle-value').textContent=Math.round(state.throttle*100)+' %';if(document.activeElement!==$('throttle'))$('throttle').value=Math.round(state.throttle*100);$('power-state').textContent=state.throttle>1?'BOOST':state.throttle<.1?'IDLE':'CRUISE';
  $('gate-count').textContent=String(gatesPassed%13|| (gatesPassed?13:0)).padStart(2,'0');$('gate-info').textContent='第 '+(gate+1)+' 道 · '+(V.len(V.sub(world.gates[gate],S.slice(0,3)))/1000).toFixed(2)+' km';
  for(let [id,value] of [['bar-p',S[24]],['bar-r',S[25]],['bar-y',S[26]]])$(id).style.setProperty('--v',Math.abs(value)*100+'%');
  let titles=['INSTRUCTOR / CAPTURE','INSTRUCTOR / ROLL ALIGN','INSTRUCTOR / PULL & CHASE','MANUAL / YOUR CONTROLS','GROUND / ROLLING','TEST ENDED'],sub=['收斂目標 · 保持世界方向','滾轉對準升力方向','拉起追蹤 · 角速度阻尼','鍵盤或搖桿接管三軸','跑道滑跑 · 逐步增加油門','與地面接觸'];
  let mode=Math.round(S[36]);let title=state.level?'LEVEL HOLD / 平飛保持':titles[mode]||titles[0],desc=state.level?'保持航向 · 迎角與垂直速度補償':sub[mode]||sub[0];
  let warning=false;if(S[21]>.40){title='STALL / 失速警告';desc='降低迎角 · 增加空速';warning=true}else if(S[17]>cfg.gLimit+.5){title='HIGH G / 過載';desc='減少拉起輸入';warning=true}else if(S[35]<85&&S[8]< -5){title='TERRAIN / 注意地面';desc='距地 '+Math.round(S[35])+' m';warning=true}else if(state.free){title='FREE LOOK / 方向保持';desc='放開 C 或右鍵後鏡頭回正'}
  $('phase-title').textContent=title;$('phase-sub').textContent=desc;$('phase').classList.toggle('warning',warning);$('engine-status').textContent='WEBGL 2 / WASM · '+(cfg.profile?'V2 REFINED':'V1 BASELINE');$('perf').textContent=manualClock?'120 Hz / OFFLINE CAPTURE':Math.round(fps)+' FPS · '+renderer.draws+' DRAWS · 120 Hz';
 }
 function startBenchmark(kind){
  const def=FlightTools.scenarios[kind];if(!def)throw Error('Unknown flight benchmark');
  state.demo=false;state.instructor=true;reset(def.spawn);state.throttle=def.throttle??.8;aim=def.aim(0);
  benchReport=null;bench={kind,profile:cfg.profile,elapsed:0,dwell:0,settle:null,peakG:0,reversals:0,lastSign:0};
  $('diagnostics').hidden=false;$('settings').hidden=true;$('help').hidden=true;$('bench-kind').value=kind;
  syncButtons();cameraUpdate(.25);drawDirty=true;toast(def.name+' · 固定輸入測試，滑鼠或按鍵可接管');
 }
 function drawDiagnostics(){
  if($('diagnostics').hidden)return;
  const refined=!!cfg.profile;
  $('diag-profile').textContent=refined?'V2 / REFINED':'V1 / BASELINE';
  $('diag-auth').textContent=refined?[58,59,60].map(k=>Math.round(S[k]*100)+'%').join(' / '):Math.round(S[28]*100)+'% · 整機';
  $('diag-limits').textContent=refined?'AoA '+Math.round(S[53]*100)+'% · G '+Math.round(S[62]*100)+'%':'V1 原始保護';
  $('diag-schedule').textContent=refined?'動壓調節 '+Math.round(S[52]*100)+'% · 航向可信度 '+S[51].toFixed(2):'未使用 V2 調節';
  const b=bench||benchReport;
  $('bench-result').textContent=b?(bench?'測試中 ':'已完成 ')+b.elapsed.toFixed(1)+' s / '+FlightTools.scenarios[b.kind].duration+' s\n'+
   '0.5° 內保持 2 s：'+(b.settle===null?'尚未達成':b.settle.toFixed(1)+' s')+' · 峰值 '+b.peakG.toFixed(2)+' G\n'+
   '滾轉反向修正 '+b.reversals+' 次'+(b.crashed?' · 已接觸地面':''):'選擇情境，V1 / V2 從相同初始狀態比較。';
  const c=$('diag-graph').getContext('2d'),w=600,h=260,rows=diagHistory.toArray();c.clearRect(0,0,w,h);
  c.fillStyle='#0d2530';c.fillRect(0,0,w,h);c.font='15px ui-monospace,monospace';c.textAlign='left';
  const panels=[{top:27,bottom:106,max:Math.max(5,...rows.map(x=>Math.min(x[1],180))),min:0,cols:[[1,'#e7c78b']],label:'AIM ERROR / °'},
   {top:158,bottom:238,max:Math.max(12,...rows.map(x=>Math.max(Math.abs(x[2]),Math.abs(x[3])))),min:null,cols:refined?[[3,'#e7c78b'],[2,'#85d6ce']]:[[2,'#85d6ce']],label:'PITCH RATE / °/s  ·  CMD / ACTUAL'}];
  for(const p of panels){if(p.min===null)p.min=-p.max;c.fillStyle='#a8c3c9';c.fillText(p.label,12,p.top-9);c.strokeStyle='#52727a55';c.lineWidth=1;
   for(let i=0;i<=2;i++){const y=p.top+(p.bottom-p.top)*i/2;c.beginPath();c.moveTo(47,y);c.lineTo(w-12,y);c.stroke();c.fillStyle='#78979f';c.font='12px monospace';c.fillText((p.max+(p.min-p.max)*i/2).toFixed(0),6,y+4)}
   const last=rows.at(-1)?.[0]||0,start=Math.max(0,last-24);
   for(const [col,color]of p.cols){c.strokeStyle=color;c.lineWidth=2;c.beginPath();let begun=false;for(const row of rows){if(row[0]<start)continue;const x=47+(row[0]-start)/24*(w-59),y=p.bottom-clamp((row[col]-p.min)/(p.max-p.min))*(p.bottom-p.top);if(!begun){c.moveTo(x,y);begun=true}else c.lineTo(x,y)}c.stroke()}
   c.font='15px ui-monospace,monospace';
  }
 }
 $('controller-profile').onchange=e=>{cfg.profile=Number(e.target.value);bench=null;benchReport=null;diagHistory.clear();configure();$('diag-profile').textContent=cfg.profile?'V2 / REFINED':'V1 / BASELINE';drawDirty=true};
 $('handoff-mode').onchange=e=>{cfg.handoff=Number(e.target.value);configure()};
 $('release-delay').oninput=e=>{cfg.releaseDelay=Number(e.target.value);$('release-delay-value').textContent=cfg.releaseDelay.toFixed(2)+' s';configure()};
 $('stick-expo').oninput=e=>{cfg.expo=Number(e.target.value);$('stick-expo-value').textContent=cfg.expo.toFixed(2)};
 $('bench-start').onclick=()=>startBenchmark($('bench-kind').value);
 $('bench-stop').onclick=()=>{bench=null;state.paused=true;syncButtons();drawDirty=true};
 $('bench-export').onclick=()=>{
  const report={version:2,coreVersion:wasm.core_version(),controller:cfg.profile?'refined':'legacy',config:{...cfg},benchmark:bench||benchReport,simulationRate:120,telemetryColumns:telemetryHeaders(),telemetry:telemetry.toArray()};
  const url=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='aerolab-v2-diagnostics.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);
 };
 function telemetryHeaders(){return ['time_s','x_m','altitude_m','z_m','ias_kmh','tas_kmh','heading_deg','pitch_deg','bank_deg','aoa_deg','sideslip_deg','normal_load_g','elevator','aileron','rudder','engine','instructor_authority','throttle','heading_confidence','q_schedule','aoa_gate','aim_error_rad','aim_rate_rad_s','pitch_integral_rad_s','yaw_integral_rad_s','pitch_authority','roll_authority','yaw_authority','controller_profile','g_gate','turn_commit','pitch_target_rad_s','roll_target_rad_s','yaw_target_rad_s','aoa_rate_rad_s','g_rate_s','heading_rate_rad_s','handoff_mode','release_delay_s','return_rate_s','roll_error_rad']}
 function updateSound(){if(!soundCtx||!soundOn)return;let now=soundCtx.currentTime,freq=35+S[27]*59;soundOsc.forEach((o,i)=>o.frequency.setTargetAtTime(freq*(i+1),now,.16));soundGain.gain.setTargetAtTime(state.paused||S[22]?0:.032+S[27]*.036,now,.14)}
 async function toggleSound(){try{if(!soundCtx){soundCtx=new (window.AudioContext||window.webkitAudioContext)();soundGain=soundCtx.createGain();soundGain.gain.value=0;let filter=soundCtx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=600;soundGain.connect(filter);filter.connect(soundCtx.destination);for(let i=0;i<3;i++){let o=soundCtx.createOscillator(),g=soundCtx.createGain();o.type=i===0?'triangle':'sine';g.gain.value=1/(i+1);o.connect(g);g.connect(soundGain);o.start();soundOsc.push(o)}}soundOn=!soundOn;if(soundOn)await soundCtx.resume();else await soundCtx.suspend();$('sound').textContent='音效 '+(soundOn?'開':'關');$('sound').classList.toggle('on',soundOn)}catch(e){toast('瀏覽器未開放音訊：'+e.message)}}
 function openPanel(id){if(mouseLocked)document.exitPointerLock?.();for(let p of ['settings','help','diagnostics'])if(p!==id)$(p).hidden=true;$(id).hidden=!$(id).hidden;drawDirty=true}
 $('diagnostics-btn').onclick=()=>openPanel('diagnostics');
 $('settings-btn').onclick=()=>openPanel('settings');$('help-btn').onclick=()=>openPanel('help');document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>{b.closest('aside').hidden=true});
 $('take-control').onclick=lockMouse;$('sound').onclick=toggleSound;$('compact').onclick=()=>{document.body.classList.toggle('compact');drawDirty=true};
 $('pause').onclick=()=>{state.paused=!state.paused;acc=0;syncButtons();drawDirty=true;updateSound()};
 $('restart').onclick=()=>reset();$('crash-restart').onclick=()=>reset();$('demo').onclick=()=>setDemo(!state.demo);
 $('instructor').onclick=()=>{state.instructor=!state.instructor;state.demo=false;state.level=false;aim=V.norm(S.slice(48,51));syncButtons();toast(state.instructor?'教官已接管，保持目前機頭方向':'教官關閉：W/S 俯仰，A/D 滾轉，Q/E 方向舵')};
 $('camera').onclick=()=>{state.camera=1-state.camera;syncButtons();cameraUpdate(.4);drawDirty=true};
 $('level').onclick=()=>{state.level=!state.level;if(state.level){state.demo=false;state.instructor=true;aim=V.norm([S[48],0,S[50]])}syncButtons();toast(state.level?'平飛保持開啟':'平飛保持關閉')};
 for(let [id,key] of [['gear','gear'],['flaps','flaps'],['airbrake','brake'],['trails','trails']])$(id).onclick=()=>{state[key]=!state[key];if(key!=='trails')state.demo=false;syncButtons();drawDirty=true};
 $('protection').onclick=()=>{cfg.protection=!cfg.protection;configure();syncButtons();toast(cfg.protection?'教官迎角／過載保護開啟':'包線保護已關閉；高迎角可能失速')};
 $('throttle').oninput=e=>{state.throttle=Number(e.target.value)/100;if(state.demo){state.demo=false;syncButtons()}drawDirty=true};
 $('scenario').onchange=e=>{state.demo=false;reset(Number(e.target.value));toast('起始情境已重置；點擊接管試飛')};
 for(let [id,k,suffix] of [['sensitivity','sensitivity',''],['response','response',''],['wind','wind',' kt'],['g-limit','gLimit',' G']])$(id).oninput=e=>{cfg[k]=Number(e.target.value);$(id+'-value').textContent=(k==='response'||k==='sensitivity'?cfg[k].toFixed(2):cfg[k])+suffix;configure()};
 $('quality').onclick=()=>{state.quality=state.quality===1?.7:state.quality===.7?1.25:1;$('quality').textContent='畫質：'+(state.quality===1?'標準':state.quality<1?'省電':'精細');drawDirty=true};
 $('export-csv').onclick=()=>{if(!telemetry.length){toast('尚無遙測記錄，請先開始飛行');return}let headers=telemetryHeaders(),csv=headers.join(',')+'\n'+telemetry.toArray().map(r=>r.map(n=>n.toFixed(5)).join(',')).join('\n');let url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download='aerolab-flight-telemetry.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);toast('已匯出 '+telemetry.length+' 筆本機飛行遙測')};
 let hotkeys={F2:'diagnostics-btn',KeyP:'pause',KeyR:'restart',KeyI:'instructor',KeyL:'level',KeyV:'camera',KeyG:'gear',KeyF:'flaps',KeyB:'airbrake',KeyH:'help-btn'};
 addEventListener('keydown',e=>{if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName))return;if(e.code==='F2'||e.code.startsWith('Arrow')||e.code.startsWith('Control')||e.code==='Space')e.preventDefault();keys.add(e.code);if(!e.repeat&&hotkeys[e.code])$(hotkeys[e.code]).click();if(e.code==='Escape'){releaseKeys();drawDirty=true}});
 addEventListener('keyup',e=>{keys.delete(e.code);drawDirty=true});
 document.addEventListener('pointerlockchange',()=>{mouseLocked=document.pointerLockElement===canvas;if(!mouseLocked)releaseKeys();syncButtons();drawDirty=true});
 canvas.addEventListener('pointerdown',e=>{if(e.button===2){freeMouse=true;state.free=true;dragging=true}else if(e.button===0){dragging=true;state.started=true;if(state.demo){state.demo=false;aim=V.norm(S.slice(48,51));syncButtons()}if(e.pointerType==='mouse'&&!mouseLocked){try{let p=canvas.requestPointerLock?.();p?.catch?.(()=>{})}catch{}}}lastPointer=[e.clientX,e.clientY];try{if(!document.pointerLockElement)canvas.setPointerCapture?.(e.pointerId)}catch{}});
 canvas.addEventListener('contextmenu',e=>e.preventDefault());
 addEventListener('pointerup',e=>{dragging=false;if(e.button===2)freeMouse=false;state.free=keys.has('KeyC')||freeMouse;lastPointer=null});
 addEventListener('pointermove',e=>{state.free=keys.has('KeyC')||freeMouse;if(mouseLocked){updateAim(clamp(e.movementX,-160,160),clamp(e.movementY,-160,160))}else if(dragging&&lastPointer){updateAim(e.clientX-lastPointer[0],e.clientY-lastPointer[1]);lastPointer=[e.clientX,e.clientY]}});
 canvas.addEventListener('wheel',e=>{e.preventDefault();state.throttle=clamp(state.throttle-Math.sign(e.deltaY)*.035,0,1.12);state.demo=false;syncButtons();drawDirty=true},{passive:false});
 document.querySelectorAll('[data-touch]').forEach(b=>{b.addEventListener('pointerdown',e=>{e.preventDefault();keys.add(b.dataset.touch);b.setPointerCapture(e.pointerId)});for(let ev of ['pointerup','pointercancel'])b.addEventListener(ev,e=>keys.delete(b.dataset.touch))});
 addEventListener('blur',releaseKeys);addEventListener('pointercancel',releaseKeys);
 document.addEventListener('visibilitychange',()=>{releaseKeys();acc=0;lastFrame=performance.now();if(document.hidden){pausedByVisibility=!state.paused;state.paused=true;if(soundCtx)soundCtx.suspend()}else if(pausedByVisibility){state.paused=false;pausedByVisibility=false;if(soundOn)soundCtx?.resume()}syncButtons();drawDirty=true});
 addEventListener('resize',()=>{width=innerWidth;height=innerHeight;drawDirty=true});
 canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();state.paused=true;fatal(Error('WebGL 繪圖環境遺失，請重新整理頁面。未繼續運算飛行物理。'))});
 function frame(now){if(disposed)return;let dt=clamp((now-lastFrame)/1000,0,.10);lastFrame=now;if(!manualClock&&!state.paused&&!document.hidden&&!S[22]){acc+=dt;let steps=0;while(acc>=FIXED&&steps<12&&!state.paused){stepOnce(FIXED);acc-=FIXED;steps++}if(steps===12)acc=0;cameraUpdate(dt,acc/FIXED);render()}else if(drawDirty){cameraUpdate(.016);render()}frames++;if(now-clockStart>1000){fps=frames*1000/(now-clockStart);frames=0;clockStart=now}requestAnimationFrame(frame)}
 configure();syncButtons();cameraUpdate(.25);render();$('boot').classList.add('ready');
 // Documented deterministic test API: never used to replace real UI input during normal play.
 window.FlightLab={ready:true,core:'C / wasm32 — refined instructor v2',wasm,
  setManualClock:(enabled)=>{manualClock=!!enabled;acc=0;lastFrame=performance.now();drawDirty=true},
  getState:()=>Array.from(S),getAim:()=>aim.slice(),getStatus:()=>({...state,profile:cfg.profile,handoff:cfg.handoff,bench:bench?.kind||null,uiUpdates,mapUpdates,dynamicBufferAllocations:renderer.dynamicAllocations||0,gate,gatesPassed,telemetrySamples:telemetry.length,drawCalls:renderer.draws,aimError:latestAimError,glError:renderer.gl.getError()}),
  reset:(scenario=0)=>{state.demo=false;reset(scenario);cameraUpdate(.25);render();return Array.from(S)},
  setAim:(a)=>{if(!Array.isArray(a)||a.length!==3||a.some(x=>!Number.isFinite(x))||V.len(a)<.01)throw Error('aim must be three finite numbers with nonzero length');aim=V.norm(a);state.demo=false;state.level=false;syncButtons();return aim.slice()},
  setMode:(changes)=>{for(let k of ['demo','paused','instructor','gear','flaps','brake','level','trails'])if(typeof changes[k]==='boolean')state[k]=changes[k];if(changes.camera===0||changes.camera===1)state.camera=changes.camera;if(Number.isFinite(changes.throttle))state.throttle=clamp(changes.throttle,0,1.12);syncButtons();drawDirty=true},
  advance:(seconds,inputs=null)=>{if(!Number.isFinite(seconds)||seconds<0||seconds>120)throw Error('seconds must be 0..120');let n=Math.round(seconds/FIXED);for(let i=0;i<n;i++){const wasBench=!!bench;stepOnce(FIXED,inputs);cameraUpdate(FIXED);if(S[22]||(wasBench&&!bench))break}render();return Array.from(S)},
  render:()=>{cameraUpdate(.1);render()},configure:(c)=>{if(Number.isFinite(c.wind))cfg.wind=clamp(c.wind,0,35);if(Number.isFinite(c.response))cfg.response=clamp(c.response,.5,1.6);if(Number.isFinite(c.gLimit))cfg.gLimit=clamp(c.gLimit,2,9);if(typeof c.protection==='boolean')cfg.protection=c.protection;if(c.profile===0||c.profile===1)cfg.profile=c.profile;if(c.handoff===0||c.handoff===1)cfg.handoff=c.handoff;if(Number.isFinite(c.releaseDelay))cfg.releaseDelay=clamp(c.releaseDelay,0,1.5);configure()},
  freeLook:(yaw,pitch)=>{freeYaw=clamp(yaw,-Math.PI,Math.PI);freePitch=clamp(pitch,-1.35,1.35);freeMouse=true;state.free=true;cameraUpdate(.1);render()},
  getPresentation:()=>({position:Array.from(R.slice(0,3)),quaternion:Array.from(R.slice(3,7)),alpha:renderAlpha,camera:cameraDir.slice(),cameraUp:camUp.slice()}),
  startBenchmark:(kind)=>startBenchmark(kind),getBenchmark:()=>bench?{...bench}:benchReport,
  setPresentationAlpha:(a)=>{cameraUpdate(.001,clamp(a));render();},
  getTelemetryHeaders:()=>telemetryHeaders(),getTelemetry:()=>telemetry.toArray().map(r=>r.slice()),terrain:(x,z)=>world.terrain(x,z)
 };
 requestAnimationFrame(frame);
}catch(e){fatal(e)}
})();
