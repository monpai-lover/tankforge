/* Pure utilities shared by live input, the renderer and regression tests. */
const FlightTools={
 shapeAxis(value,deadzone=.12,expo=.35){
  if(!Number.isFinite(value))return 0;
  const d=clamp(deadzone,0,.5),e=clamp(expo,0,.9),a=clamp(Math.abs(value),0,1);
  if(a<=d)return 0;const x=(a-d)/(1-d);return Math.sign(value)*((1-e)*x+e*x*x*x);
 },
 lookQuaternion(forward,up=[0,1,0]){
  const f=V.norm(forward);let r=V.cross(up,f);
  if(V.len(r)<1e-5)r=V.cross(Math.abs(f[0])<.8?[1,0,0]:[0,0,1],f);
  r=V.norm(r);const u=V.cross(f,r),m00=r[0],m11=u[1],m22=f[2],tr=m00+m11+m22;let q;
  if(tr>0){let s=Math.sqrt(1+tr)*2;q=[(u[2]-f[1])/s,(f[0]-r[2])/s,(r[1]-u[0])/s,s/4]}
  else if(m00>m11&&m00>m22){let s=Math.sqrt(1+m00-m11-m22)*2;q=[s/4,(u[0]+r[1])/s,(f[0]+r[2])/s,(u[2]-f[1])/s]}
  else if(m11>m22){let s=Math.sqrt(1+m11-m00-m22)*2;q=[(u[0]+r[1])/s,s/4,(f[1]+u[2])/s,(f[0]-r[2])/s]}
  else{let s=Math.sqrt(1+m22-m00-m11)*2;q=[(f[0]+r[2])/s,(f[1]+u[2])/s,s/4,(r[1]-u[0])/s]}
  const n=Math.hypot(...q);return q.map(x=>x/n);
 },
 interpolate(a,b,t,out){out.set(b);t=clamp(t);for(let k=0;k<3;k++)out[k]=mix(a[k],b[k],t);out.set(Q.slerp(Array.from(a.slice(3,7)),Array.from(b.slice(3,7)),t),3);out[23]=mix(a[23],b[23],t);for(let j=0;j<3;j++)out.set(Q.rot(Array.from(out.slice(3,7)),j===0?[1,0,0]:j===1?[0,1,0]:[0,0,1]),42+j*3);return out;},
 direction(heading,elevation=1.2){const h=heading*DEG,e=elevation*DEG;return [Math.sin(h)*Math.cos(e),Math.sin(e),Math.cos(h)*Math.cos(e)]},
 scenarios:{turn:{name:'60° 轉向收斂',spawn:0,duration:25,aim:t=>FlightTools.direction(60)},reversal:{name:'高速反向轉彎',spawn:3,duration:35,aim:t=>FlightTools.direction(t<6?60:-60)},rear:{name:'正後方目標抖動',spawn:3,duration:30,aim:t=>FlightTools.direction(t<4?179+2*Math.sin(t*13):179)},slow:{name:'低動壓長時滑翔',spawn:2,duration:90,throttle:.06,aim:t=>FlightTools.direction(0)},vertical:{name:'大仰角幾何測試',spawn:3,duration:12,aim:t=>FlightTools.direction(0,82)}}
};
class FlightRing{
 constructor(capacity){this.capacity=capacity;this.data=[];this.head=0}
 get length(){return this.data.length}
 push(row){if(this.length<this.capacity)this.data.push(row);else{this.data[this.head]=row;this.head=(this.head+1)%this.capacity}}
 clear(){this.data.length=0;this.head=0}
 toArray(){return this.head?this.data.slice(this.head).concat(this.data.slice(0,this.head)):this.data.slice()}
}
