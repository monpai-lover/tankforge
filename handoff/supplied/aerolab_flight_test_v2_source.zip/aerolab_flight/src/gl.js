'use strict';
const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),mix=(a,b,t)=>a+(b-a)*t,smooth=(a,b,x)=>{let t=clamp((x-a)/(b-a));return t*t*(3-2*t)},TAU=Math.PI*2,DEG=Math.PI/180;
const V={add:(a,b)=>a.map((x,i)=>x+b[i]),sub:(a,b)=>a.map((x,i)=>x-b[i]),mul:(a,s)=>a.map(x=>x*s),dot:(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0),cross:(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],len:a=>Math.hypot(...a),norm:a=>{let l=Math.hypot(...a)||1;return a.map(x=>x/l)},lerp:(a,b,t)=>a.map((x,i)=>mix(x,b[i],t))};
const Q={mul:(a,b)=>[a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]],axis:(a,t)=>[...V.mul(a,Math.sin(t/2)),Math.cos(t/2)],rot:(q,a)=>{let t=V.mul(V.cross(q.slice(0,3),a),2);return V.add(a,V.add(V.mul(t,q[3]),V.cross(q.slice(0,3),t)))},slerp:(a,b,t)=>{let d=a.reduce((s,x,i)=>s+x*b[i],0);if(d<0){b=b.map(x=>-x);d=-d}if(d>.9995){let q=V.lerp(a,b,t);return q.map(x=>x/Math.hypot(...q))}let th=Math.acos(clamp(d,-1,1)),s=Math.sin(th);return a.map((x,i)=>(x*Math.sin((1-t)*th)+b[i]*Math.sin(t*th))/s)}};
const M={
 id:()=>new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]),
 mul:(a,b)=>{let r=new Float32Array(16);for(let j=0;j<4;j++)for(let i=0;i<4;i++)for(let k=0;k<4;k++)r[j*4+i]+=a[k*4+i]*b[j*4+k];return r},
 perspective:(fov,ar,n=.3,f=50000)=>{let q=1/Math.tan(fov/2);return new Float32Array([q/ar,0,0,0,0,q,0,0,0,0,(f+n)/(f-n),1,0,0,-2*f*n/(f-n),0])},
 look:(eye,target,up=[0,1,0])=>{let z=V.norm(V.sub(target,eye)),x=V.norm(V.cross(up,z));if(V.len(x)<.1)x=[1,0,0];let y=V.cross(z,x);return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-V.dot(x,eye),-V.dot(y,eye),-V.dot(z,eye),1])},
 trs:(p=[0,0,0],q=[0,0,0,1],s=[1,1,1])=>{let [x,y,z,w]=q,xx=x*x,yy=y*y,zz=z*z;return new Float32Array([(1-2*(yy+zz))*s[0],2*(x*y+z*w)*s[0],2*(x*z-y*w)*s[0],0,2*(x*y-z*w)*s[1],(1-2*(xx+zz))*s[1],2*(y*z+x*w)*s[1],0,2*(x*z+y*w)*s[2],2*(y*z-x*w)*s[2],(1-2*(xx+yy))*s[2],0,...p,1])},
 point:(m,p)=>[m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]],
 dir:(m,p)=>[m[0]*p[0]+m[4]*p[1]+m[8]*p[2],m[1]*p[0]+m[5]*p[1]+m[9]*p[2],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]],
 axis:(a,b,r)=>{let z=V.norm(V.sub(b,a)),x=V.norm(V.cross(Math.abs(z[1])>.95?[1,0,0]:[0,1,0],z)),y=V.cross(z,x),l=V.len(V.sub(b,a));return new Float32Array([...V.mul(x,r),0,...V.mul(y,r),0,...V.mul(z,l),0,...V.lerp(a,b,.5),1])}
};
const color=h=>Array.isArray(h)?h:[1,3,5].map(i=>Math.pow(parseInt(h.slice(i,i+2),16)/255,2.2));
function mesh(p,i,n=null,c=null){if(!n){n=new Array(p.length).fill(0);for(let k=0;k<i.length;k+=3){let a=i[k]*3,b=i[k+1]*3,d=i[k+2]*3,N=V.cross(V.sub(p.slice(b,b+3),p.slice(a,a+3)),V.sub(p.slice(d,d+3),p.slice(a,a+3)));for(let u of [a,b,d])for(let j=0;j<3;j++)n[u+j]+=N[j]}for(let k=0;k<n.length;k+=3)n.splice(k,3,...V.norm(n.slice(k,k+3)))}return {p,i,n,c}}
function faces(fs){let p=[],n=[],idx=[];for(let f of fs){let k=p.length/3,N=V.norm(V.cross(V.sub(f[1],f[0]),V.sub(f[2],f[0])));for(let a of f){p.push(...a);n.push(...N)}for(let j=1;j<f.length-1;j++)idx.push(k,k+j,k+j+1)}return mesh(p,idx,n)}
const box=faces([ [[-.5,-.5,-.5],[-.5,.5,-.5],[.5,.5,-.5],[.5,-.5,-.5]], [[-.5,-.5,.5],[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5]], [[-.5,.5,-.5],[-.5,.5,.5],[.5,.5,.5],[.5,.5,-.5]], [[-.5,-.5,-.5],[.5,-.5,-.5],[.5,-.5,.5],[-.5,-.5,.5]], [[-.5,-.5,-.5],[-.5,-.5,.5],[-.5,.5,.5],[-.5,.5,-.5]], [[.5,-.5,-.5],[.5,.5,-.5],[.5,.5,.5],[.5,-.5,.5]] ]);
function lathe(profile,n=24){let p=[],i=[];for(let [z,rx,ry] of profile)for(let k=0;k<=n;k++){let a=k/n*TAU;p.push(Math.cos(a)*rx,Math.sin(a)*(ry??rx),z)}for(let j=0;j<profile.length-1;j++)for(let k=0;k<n;k++){let a=j*(n+1)+k,b=a+n+1;i.push(a,a+1,b,a+1,b+1,b)}return mesh(p,i)}
const sphere=lathe(Array.from({length:19},(_,i)=>{let a=i/18*Math.PI;return [-Math.cos(a),Math.sin(a)]}),28),cylinder=lathe([[-.5,0],[-.5,1],[.5,1],[.5,0]],24);
function torus(rad,tube,arc=TAU,n=72,m=8){let p=[],ix=[];for(let a=0;a<=n;a++)for(let b=0;b<=m;b++){let th=a/n*arc,ph=b/m*TAU,r=rad+tube*Math.cos(ph);p.push(Math.cos(th)*r,Math.sin(th)*r,Math.sin(ph)*tube)}for(let a=0;a<n;a++)for(let b=0;b<m;b++){let k=a*(m+1)+b;ix.push(k,k+m+1,k+1,k+1,k+m+1,k+m+2)}return mesh(p,ix)}
class Batch{
 constructor(){this.parts=[]}
 add(g,p=[0,0,0],s=[1,1,1],c='#ffffff',kind=0,q=[0,0,0,1],alpha=1){this.parts.push({g,m:M.trs(p,q,s),c:color(c),kind,alpha});return this}
 box(p,s,c,kind=0,q=[0,0,0,1]){return this.add(box,p,s,c,kind,q)}
 ball(p,s,c,kind=0){return this.add(sphere,p,s,c,kind)}
 rod(a,b,r,c,kind=0){this.parts.push({g:cylinder,m:M.axis(a,b,r),c:color(c),kind,alpha:1});return this}
 finish(renderer){let bins=new Map;for(let v of this.parts){let key=v.kind+'|'+v.alpha;if(!bins.has(key))bins.set(key,{p:[],i:[],n:[],c:[],kind:v.kind,alpha:v.alpha});let b=bins.get(key),base=b.p.length/3;for(let k=0;k<v.g.p.length;k+=3){b.p.push(...M.point(v.m,v.g.p.slice(k,k+3)));let n=v.g.n.slice(k,k+3),x=[v.m[0],v.m[1],v.m[2]],y=[v.m[4],v.m[5],v.m[6]],z=[v.m[8],v.m[9],v.m[10]];b.n.push(...V.norm(V.add(V.add(V.mul(x,n[0]/Math.max(V.dot(x,x),1e-8)),V.mul(y,n[1]/Math.max(V.dot(y,y),1e-8))),V.mul(z,n[2]/Math.max(V.dot(z,z),1e-8)))));b.c.push(...v.c)}b.i.push(...v.g.i.map(i=>i+base))}return [...bins.values()].map(b=>({gpu:renderer.upload(b),kind:b.kind,alpha:b.alpha,model:M.id()}))}
}
const VS=`#version 300 es
precision highp float;
layout(location=0)in vec3 aPos;layout(location=1)in vec3 aNormal;layout(location=2)in vec3 aColor;
uniform mat4 uModel,uVP;out vec3 vWorld,vNormal,vColor,vLocal;
void main(){vec4 p=uModel*vec4(aPos,1.);vWorld=p.xyz;vNormal=transpose(inverse(mat3(uModel)))*aNormal;vColor=aColor;vLocal=aPos;gl_Position=uVP*p;}`;
const NOISE=`float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}float fbm(vec2 p){return .55*noise(p)+.27*noise(p*2.07)+.12*noise(p*4.13)+.06*noise(p*8.03);}`;
const FS=`#version 300 es
precision highp float;
in vec3 vWorld,vNormal,vColor,vLocal;out vec4 frag;
uniform vec3 uEye,uSun;uniform int uKind;uniform float uTime,uAlpha;
${NOISE}
vec3 tonemap(vec3 c){return pow(clamp((c*(2.51*c+.03))/(c*(2.43*c+.59)+.14),0.,1.),vec3(1./2.2));}
void main(){vec3 N=normalize(vNormal);if(dot(N,uEye-vWorld)<0.)N=-N;vec3 view=normalize(uEye-vWorld),base=vColor;float rough=.45,alpha=uAlpha;
if(uKind==1){float h=vWorld.y,coarse=fbm(vWorld.xz*.003),fine=noise(vWorld.xz*.06);vec3 grass=mix(vec3(.059,.12,.062),vec3(.19,.23,.10),coarse);vec3 sand=vec3(.53,.48,.31);base=mix(sand,grass,smoothstep(3.,36.,h));base=mix(base,vec3(.28,.3,.255),smoothstep(.35,.65,1.-N.y)*.72);base=mix(base,vec3(.4,.42,.36),smoothstep(430.,670.,h));base*=.82+.28*fine;rough=.94;}
if(uKind==2){float fade=1./(1.+length(fwidth(vWorld.xz))*.075);float warp=noise(vWorld.xz*.008)*5.;float a=sin(vWorld.x*.053+vWorld.z*.08+warp+uTime*.75),b=cos(vWorld.x*.091-vWorld.z*.041+warp+uTime*.51);N=normalize(vec3(a*.045*fade,1.,b*.045*fade));float fres=pow(1.-max(dot(N,view),0.),4.);base=mix(vec3(.019,.115,.16),vec3(.46,.57,.61),fres);float rip=noise(vWorld.xz*.018+uTime*.018);base*=.85+.2*rip;rough=.10;}
if(uKind==3){float rivet=(1.-smoothstep(.025,.09,length(fract(vec2(vLocal.z*3.4,vLocal.x*4.8))-.5)))*.10;float panel=1.-smoothstep(.008,.025,abs(fract(vLocal.z*1.8)-.5));base*=.91+.1*noise(vLocal.xz*95.)-.12*panel-rivet;rough=.27;}
if(uKind==4){float f=pow(1.-abs(dot(N,view)),3.);base=mix(vec3(.023,.077,.11),vec3(.48,.66,.71),f);alpha*=.55+.45*f;rough=.07;}
float nd=max(dot(N,uSun),0.);vec3 hemi=mix(vec3(.16,.19,.14),vec3(.42,.51,.63),N.y*.5+.5);vec3 light=hemi*.72+vec3(1.45,1.30,1.07)*nd;vec3 h=normalize(view+uSun);float spec=pow(max(dot(N,h),0.),mix(180.,9.,rough));vec3 col=base*light+spec*mix(.6,.04,rough)*vec3(1.,.9,.73);
if(uKind==5)col=base*2.4;
if(uKind==7){col=base;alpha*=.65;}
float d=distance(uEye,vWorld),fog=1.-exp(-d*.000080);vec3 haze=mix(vec3(.38,.54,.62),vec3(.76,.72,.59),pow(max(dot(normalize(vWorld-uEye),uSun),0.),5.));col=mix(col,haze,fog);
frag=vec4(tonemap(col),alpha);}`;
const QUAD=`#version 300 es
precision highp float;out vec2 uv;void main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);uv=p;gl_Position=vec4(p*2.-1.,0,1);}`;
const SKY=`#version 300 es
precision highp float;in vec2 uv;out vec4 frag;uniform vec3 uForward,uRight,uUp,uSun,uEye;uniform vec2 uAspectFov;uniform float uTime;
${NOISE}
void main(){vec2 p=uv*2.-1.;vec3 d=normalize(uForward+uRight*p.x*uAspectFov.x*uAspectFov.y+uUp*p.y*uAspectFov.y);float y=max(d.y,0.);vec3 col=mix(vec3(.79,.83,.80),vec3(.31,.56,.73),sqrt(clamp(y,0.,1.)));float s=max(dot(d,uSun),0.);col+=vec3(.23,.14,.045)*pow(s,16.);col+=vec3(1.,.79,.40)*pow(s,1900.);
float cy=1650.-uEye.y;if(cy*d.y>0.){float k=clamp(cy/(d.y==0.? .0001:d.y),0.,80000.);vec2 plane=(uEye.xz+d.xz*k)*.00036+vec2(uTime*.0009,0.);float f=fbm(plane),c=smoothstep(.53,.72,f);float detail=fbm(plane*2.3);c*=smoothstep(.018,.15,abs(d.y))*(1.-smoothstep(23000.,50000.,k));vec3 cloud=mix(vec3(.65,.70,.69),vec3(.99,.96,.86),smoothstep(.38,.63,detail));col=mix(col,cloud,c*.8);}
float vign=1.-.08*dot(uv-.5,uv-.5);frag=vec4(clamp(col*vign,0.,1.),1.);}`;
class Renderer{
 constructor(canvas){this.canvas=canvas;const gl=this.gl=canvas.getContext('webgl2',{antialias:true,alpha:false,powerPreference:'high-performance',preserveDrawingBuffer:false});if(!gl)throw Error('需要支援 WebGL 2 的瀏覽器。請啟用硬體加速後重試。');this.program=this.programOf(VS,FS);this.sky=this.programOf(QUAD,SKY);this.draws=0;this.sun=V.norm([-0.55,.55,-.38]);this.uniforms=new Map;this.dpr=1;gl.enable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);}
 programOf(v,f){let gl=this.gl;function sh(t,s){let a=gl.createShader(t);gl.shaderSource(a,s);gl.compileShader(a);if(!gl.getShaderParameter(a,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(a));return a}let p=gl.createProgram(),a=sh(gl.VERTEX_SHADER,v),b=sh(gl.FRAGMENT_SHADER,f);gl.attachShader(p,a);gl.attachShader(p,b);gl.linkProgram(p);gl.deleteShader(a);gl.deleteShader(b);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p}
 loc(p,n){let key=this.uniforms.get(p);if(!key){key=new Map;this.uniforms.set(p,key)}if(!key.has(n))key.set(n,this.gl.getUniformLocation(p,n));return key.get(n)}
 upload(g){let gl=this.gl,vao=gl.createVertexArray();gl.bindVertexArray(vao);let all=new Float32Array(g.p.length/3*9);for(let i=0;i<g.p.length/3;i++){all.set(g.p.slice(i*3,i*3+3),i*9);all.set(g.n.slice(i*3,i*3+3),i*9+3);all.set(g.c?g.c.slice(i*3,i*3+3):[1,1,1],i*9+6)}let vb=gl.createBuffer(),ib=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,all,gl.STATIC_DRAW);for(let i=0;i<3;i++){gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,3,gl.FLOAT,false,36,i*12)}gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint32Array(g.i),gl.STATIC_DRAW);return {vao,vb,ib,count:g.i.length}}
 update(gpu,g){let gl=this.gl,all=new Float32Array(g.p.length/3*9);for(let i=0;i<g.p.length/3;i++){all.set(g.p.slice(i*3,i*3+3),i*9);all.set(g.n.slice(i*3,i*3+3),i*9+3);all.set(g.c?g.c.slice(i*3,i*3+3):[1,1,1],i*9+6)}gl.bindVertexArray(gpu.vao);gl.bindBuffer(gl.ARRAY_BUFFER,gpu.vb);gl.bufferData(gl.ARRAY_BUFFER,all,gl.DYNAMIC_DRAW);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,gpu.ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint32Array(g.i),gl.DYNAMIC_DRAW);gpu.count=g.i.length}
 createDynamic(vertexCapacity,indices){const gl=this.gl,vao=gl.createVertexArray(),vb=gl.createBuffer(),ib=gl.createBuffer();gl.bindVertexArray(vao);gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,vertexCapacity*36,gl.DYNAMIC_DRAW);for(let i=0;i<3;i++){gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,3,gl.FLOAT,false,36,i*12)}gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,indices,gl.STATIC_DRAW);this.dynamicAllocations=(this.dynamicAllocations||0)+1;return {vao,vb,ib,count:0,capacity:vertexCapacity}}
 updateDynamic(gpu,data,floatCount,indexCount){const gl=this.gl;if(floatCount>gpu.capacity*9)throw Error('Dynamic vertex capacity exceeded');gl.bindVertexArray(gpu.vao);gl.bindBuffer(gl.ARRAY_BUFFER,gpu.vb);gl.bufferSubData(gl.ARRAY_BUFFER,0,data,0,floatCount);gpu.count=indexCount;}
 dispose(g){let gl=this.gl;gl.deleteBuffer(g.vb);gl.deleteBuffer(g.ib);gl.deleteVertexArray(g.vao)}
 resize(w,h,quality=1){let d=Math.min(window.devicePixelRatio||1,1.7)*quality;this.dpr=d;let cw=Math.round(w*d),ch=Math.round(h*d);if(this.canvas.width!==cw||this.canvas.height!==ch){this.canvas.width=cw;this.canvas.height=ch}this.gl.viewport(0,0,cw,ch)}
 begin(cam,time){this.cam=cam;this.time=time;this.draws=0;let gl=this.gl,p=this.sky;gl.depthMask(true);gl.clearColor(.4,.6,.7,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.disable(gl.BLEND);gl.disable(gl.DEPTH_TEST);gl.depthMask(false);gl.useProgram(p);let f=V.norm(V.sub(cam.target,cam.eye)),right=V.norm(V.cross(cam.up||[0,1,0],f)),up=V.cross(f,right);this.viewForward=f;this.viewRight=right;this.viewUp=up;gl.uniform3fv(this.loc(p,'uForward'),f);gl.uniform3fv(this.loc(p,'uRight'),right);gl.uniform3fv(this.loc(p,'uUp'),up);gl.uniform3fv(this.loc(p,'uEye'),cam.eye);gl.uniform3fv(this.loc(p,'uSun'),this.sun);gl.uniform2f(this.loc(p,'uAspectFov'),this.canvas.width/this.canvas.height,Math.tan(cam.fov/2));gl.uniform1f(this.loc(p,'uTime'),time);gl.bindVertexArray(null);gl.drawArrays(gl.TRIANGLES,0,3);gl.enable(gl.DEPTH_TEST);gl.depthMask(true);p=this.program;gl.useProgram(p);this.vp=M.mul(M.perspective(cam.fov,this.canvas.width/this.canvas.height,cam.near||.25),M.look(cam.eye,cam.target,cam.up));gl.uniformMatrix4fv(this.loc(p,'uVP'),false,this.vp);gl.uniform3fv(this.loc(p,'uEye'),cam.eye);gl.uniform3fv(this.loc(p,'uSun'),this.sun);gl.uniform1f(this.loc(p,'uTime'),time);}
 draw(part,parent=null){let gl=this.gl,p=this.program;gl.useProgram(p);if(part.alpha<.999){gl.enable(gl.BLEND);gl.depthMask(false)}else{gl.disable(gl.BLEND);gl.depthMask(true)}gl.uniform1i(this.loc(p,'uKind'),part.kind||0);gl.uniform1f(this.loc(p,'uAlpha'),part.alpha??1);gl.uniformMatrix4fv(this.loc(p,'uModel'),false,parent?M.mul(parent,part.model):part.model);gl.bindVertexArray(part.gpu.vao);gl.drawElements(gl.TRIANGLES,part.gpu.count,gl.UNSIGNED_INT,0);this.draws++}
 group(parts,parent=null){for(let p of parts)this.draw(p,parent)}
 project(p,w=innerWidth,h=innerHeight){let m=this.vp;if(!m)return null;let d=m[3]*p[0]+m[7]*p[1]+m[11]*p[2]+m[15];let x=(m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12])/d,y=(m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13])/d;return {x:(x*.5+.5)*w,y:(.5-y*.5)*h,front:d>0,ndc:[x,y]}}
}
