"""Build a self-contained offline HTML. No runtime CDN or external fetch."""
from pathlib import Path
import base64
ROOT=Path(__file__).resolve().parent
code='\n'.join((ROOT/'src'/name).read_text(encoding='utf-8') for name in ['gl.js','flight_tools.js','scene.js','runtime.js'])
if '</script' in code.lower():
    raise ValueError('Unexpected closing script token in JavaScript')
html=(ROOT/'src/template.html').read_text(encoding='utf-8').replace('{{WASM}}',base64.b64encode((ROOT/'assets/flight_core.wasm').read_bytes()).decode()).replace('{{CODE}}',code)
(ROOT/'index.html').write_text(html,encoding='utf-8')
print(f'Built index.html: {len(html.encode()):,} bytes; WASM {len((ROOT/"assets/flight_core.wasm").read_bytes()):,} bytes')
