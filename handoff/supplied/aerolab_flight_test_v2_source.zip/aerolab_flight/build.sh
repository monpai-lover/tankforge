#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
clang --target=wasm32 -O2 -ffreestanding -nostdlib -fno-builtin src/flight_core.c \
 -Wl,--no-entry -Wl,--export=reset -Wl,--export=step -Wl,--export=configure \
 -Wl,--export=configure_control -Wl,--export=state_ptr -Wl,--export=state_len -Wl,--export=core_version -Wl,--export=terrain_height \
 -Wl,--export-memory -Wl,--initial-memory=131072 -Wl,--max-memory=131072 -Wl,-z,stack-size=32768 \
 -o assets/flight_core.wasm
python3 pack.py
