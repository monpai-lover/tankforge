"""Local-only static server. No uploads, remote access or external dependencies."""
from __future__ import annotations
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
import webbrowser


def main() -> None:
    parser = argparse.ArgumentParser(description='AEROLAB local flight test')
    parser.add_argument('--port', type=int, default=8086)
    parser.add_argument('--open', action='store_true', help='Open the system browser')
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:
        parser.error('--port must be in 0..65535')
    handler = partial(SimpleHTTPRequestHandler, directory=str(Path(__file__).resolve().parent))
    try:
        server = ThreadingHTTPServer(('127.0.0.1', args.port), handler)
    except OSError:
        # An occupied preferred port is not a reason to alter security settings.
        server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    url = f'http://127.0.0.1:{server.server_port}/index.html'
    print(f'\nAEROLAB: {url}\nLocal access only. Ctrl+C to stop.\n', flush=True)
    if args.open:
        threading.Timer(0.3, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nStopped.')
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
